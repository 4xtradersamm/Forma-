import type { Config } from 'tailwindcss';

// Apex Trading Lab design system:
// near-black charcoal background, white type, subtle gray borders,
// single restrained accent (emerald). Change ACCENT below to rebrand.
const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        background: '#0a0a0b',
        surface: '#111113',
        'surface-hover': '#17171a',
        border: '#232326',
        foreground: '#f2f2f3',
        muted: '#9a9aa2',
        accent: {
          DEFAULT: '#10b981',
          hover: '#0ea371',
          muted: '#0f2e24',
        },
        danger: '#ef4444',
        warning: '#f59e0b',
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-jetbrains-mono)', 'monospace'],
      },
      borderRadius: {
        lg: '0.75rem',
        xl: '1rem',
      },
    },
  },
  plugins: [],
};
export default config;
