'use client';

import { useActionState } from 'react';
import { createBacktestSessionAction, type ActionState } from '@/app/actions/backtest';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function NewSessionForm() {
  const [state, formAction, isPending] = useActionState(createBacktestSessionAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="model">Model</Label>
        <select id="model" name="model" className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" required>
          <option value="QT">QT</option>
          <option value="GXT">GXT</option>
          <option value="TTFM">TTFM</option>
          <option value="OTHER">Other</option>
        </select>
      </div>
      <div>
        <Label htmlFor="instrument">Instrument</Label>
        <Input id="instrument" name="instrument" placeholder="NQ" required />
        <FieldError>{state.fieldErrors?.instrument}</FieldError>
      </div>
      <div>
        <Label htmlFor="timeframe">Timeframe</Label>
        <Input id="timeframe" name="timeframe" placeholder="5m" required />
        <FieldError>{state.fieldErrors?.timeframe}</FieldError>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label htmlFor="date_range_start">Testing start date</Label><Input id="date_range_start" name="date_range_start" type="date" /></div>
        <div><Label htmlFor="date_range_end">Testing end date</Label><Input id="date_range_end" name="date_range_end" type="date" /></div>
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" isLoading={isPending}>Create session</Button>
    </form>
  );
}
