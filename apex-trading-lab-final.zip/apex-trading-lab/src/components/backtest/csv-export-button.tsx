'use client';

import Papa from 'papaparse';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';

export function BacktestCsvExportButton({ sessionId }: { sessionId: string }) {
  const [loading, setLoading] = useState(false);

  async function handleExport() {
    setLoading(true);
    const supabase = createClient();
    const { data, error } = await supabase.from('backtest_trades').select('*').eq('session_id', sessionId);
    setLoading(false);
    if (error || !data) {
      alert('Export failed: ' + (error?.message ?? 'unknown error'));
      return;
    }
    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backtest-${sessionId}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return <Button variant="secondary" onClick={handleExport} isLoading={loading}>Export CSV</Button>;
}
