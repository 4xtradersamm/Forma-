'use client';

import { useActionState } from 'react';
import { createBacktestTradeAction, type ActionState } from '@/app/actions/backtest';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScreenshotUpload } from '@/components/journal/screenshot-upload';

const initialState: ActionState = {};

export function AddTradeForm({ sessionId, userId }: { sessionId: string; userId: string }) {
  const boundAction = createBacktestTradeAction.bind(null, sessionId);
  const [state, formAction, isPending] = useActionState(boundAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div><Label htmlFor="setup_date">Setup date</Label><Input id="setup_date" name="setup_date" type="date" required /><FieldError>{state.fieldErrors?.setup_date}</FieldError></div>
        <div>
          <Label htmlFor="outcome">Outcome</Label>
          <select id="outcome" name="outcome" className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" required>
            <option value="win">Win</option>
            <option value="loss">Loss</option>
            <option value="breakeven">Breakeven</option>
            <option value="invalid">Invalid setup</option>
          </select>
        </div>
      </div>
      <div className="grid md:grid-cols-4 gap-4">
        <div><Label htmlFor="entry_price">Entry</Label><Input id="entry_price" name="entry_price" type="number" step="any" /></div>
        <div><Label htmlFor="stop_loss_price">Stop</Label><Input id="stop_loss_price" name="stop_loss_price" type="number" step="any" /></div>
        <div><Label htmlFor="take_profit_price">Target</Label><Input id="take_profit_price" name="take_profit_price" type="number" step="any" /></div>
        <div><Label htmlFor="r_multiple">R-multiple</Label><Input id="r_multiple" name="r_multiple" type="number" step="any" /></div>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="all_rules_satisfied" value="true" className="rounded border-border" />
        Every model rule was satisfied for this setup
      </label>
      <ScreenshotUpload name="chart_image_url" label="Chart screenshot" userId={userId} />
      <div>
        <Label htmlFor="notes">Notes</Label>
        <textarea id="notes" name="notes" rows={2} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" isLoading={isPending}>Add setup</Button>
    </form>
  );
}
