'use client';

import { useActionState } from 'react';
import Link from 'next/link';
import { signInAction, type ActionState } from '@/app/actions/auth';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function SignInForm() {
  const [state, formAction, isPending] = useActionState(signInAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="email" required />
        <FieldError>{state.fieldErrors?.email}</FieldError>
      </div>
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label htmlFor="password" className="block text-sm font-medium">Password</label>
          <Link href="/forgot-password" className="text-xs text-accent hover:underline">Forgot password?</Link>
        </div>
        <Input id="password" name="password" type="password" autoComplete="current-password" required />
        <FieldError>{state.fieldErrors?.password}</FieldError>
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" className="w-full" isLoading={isPending}>Sign in</Button>
    </form>
  );
}
