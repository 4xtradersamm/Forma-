'use client';

import { useActionState } from 'react';
import { forgotPasswordAction, type ActionState } from '@/app/actions/auth';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function ForgotPasswordForm() {
  const [state, formAction, isPending] = useActionState(forgotPasswordAction, initialState);

  if (state.success) {
    return (
      <div className="card text-center">
        <h2 className="font-medium">Check your email</h2>
        <p className="mt-2 text-sm text-muted">
          If an account exists for that address, we&apos;ve sent a password reset link.
        </p>
      </div>
    );
  }

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="email" required />
        <FieldError>{state.fieldErrors?.email}</FieldError>
      </div>
      <Button type="submit" className="w-full" isLoading={isPending}>Send reset link</Button>
    </form>
  );
}
