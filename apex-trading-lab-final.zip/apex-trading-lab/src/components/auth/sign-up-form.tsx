'use client';

import { useActionState } from 'react';
import { signUpAction, type ActionState } from '@/app/actions/auth';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function SignUpForm() {
  const [state, formAction, isPending] = useActionState(signUpAction, initialState);

  if (state.success) {
    return (
      <div className="card text-center">
        <h2 className="font-medium">Check your email</h2>
        <p className="mt-2 text-sm text-muted">
          We sent a verification link to confirm your account. Click it to finish signing up.
        </p>
      </div>
    );
  }

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="email" required />
        <FieldError>{state.fieldErrors?.email}</FieldError>
      </div>
      <div>
        <Label htmlFor="password">Password</Label>
        <Input id="password" name="password" type="password" autoComplete="new-password" required />
        <FieldError>{state.fieldErrors?.password}</FieldError>
        <p className="mt-1 text-xs text-muted">At least 8 characters, one uppercase letter, one number.</p>
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" className="w-full" isLoading={isPending}>Create account</Button>
    </form>
  );
}
