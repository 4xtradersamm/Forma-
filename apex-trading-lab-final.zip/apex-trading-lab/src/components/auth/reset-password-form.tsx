'use client';

import { useActionState } from 'react';
import { resetPasswordAction, type ActionState } from '@/app/actions/auth';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function ResetPasswordForm() {
  const [state, formAction, isPending] = useActionState(resetPasswordAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="password">New password</Label>
        <Input id="password" name="password" type="password" autoComplete="new-password" required />
        <FieldError>{state.fieldErrors?.password}</FieldError>
      </div>
      <div>
        <Label htmlFor="confirmPassword">Confirm new password</Label>
        <Input id="confirmPassword" name="confirmPassword" type="password" autoComplete="new-password" required />
        <FieldError>{state.fieldErrors?.confirmPassword}</FieldError>
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" className="w-full" isLoading={isPending}>Update password</Button>
    </form>
  );
}
