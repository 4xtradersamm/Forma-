'use client';

import { useState, useMemo } from 'react';
import { dailyLossLimitReached } from '@/lib/finance/calculators';
import { Input, Label } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

export function DailyLossLimitCalculator() {
  const [accountBalance, setAccountBalance] = useState(10000);
  const [dailyLossLimitPercent, setDailyLossLimitPercent] = useState(3);
  const [realizedLossToday, setRealizedLossToday] = useState(0);
  const [currency, setCurrency] = useState('USD');

  const result = useMemo(
    () => dailyLossLimitReached(realizedLossToday, accountBalance, dailyLossLimitPercent),
    [realizedLossToday, accountBalance, dailyLossLimitPercent]
  );
  const fmt = (n: number) => n.toLocaleString(undefined, { style: 'currency', currency });

  return (
    <Card>
      <h2 className="font-medium mb-4">Daily loss-limit calculator</h2>
      <div className="grid md:grid-cols-4 gap-4">
        <div><Label htmlFor="dll-balance">Account balance</Label><Input id="dll-balance" type="number" value={accountBalance} onChange={(e) => setAccountBalance(Number(e.target.value))} /></div>
        <div>
          <Label htmlFor="dll-currency">Currency</Label>
          <select id="dll-currency" value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="USD">USD</option><option value="EUR">EUR</option><option value="GBP">GBP</option><option value="INR">INR</option>
          </select>
        </div>
        <div><Label htmlFor="dll-limit-pct">Daily loss limit %</Label><Input id="dll-limit-pct" type="number" step="0.1" value={dailyLossLimitPercent} onChange={(e) => setDailyLossLimitPercent(Number(e.target.value))} /></div>
        <div><Label htmlFor="dll-realized">Realized loss today</Label><Input id="dll-realized" type="number" value={realizedLossToday} onChange={(e) => setRealizedLossToday(Number(e.target.value))} /></div>
      </div>
      <div className="mt-6 grid grid-cols-3 gap-4 text-center border-t border-border pt-4">
        <div><p className="text-xl font-mono">{fmt(result.limit)}</p><p className="text-xs text-muted mt-1">Daily limit</p></div>
        <div><p className={`text-xl font-mono ${result.reached ? 'text-danger' : 'text-accent'}`}>{result.reached ? 'Reached' : 'OK'}</p><p className="text-xs text-muted mt-1">Status</p></div>
        <div><p className="text-xl font-mono">{fmt(result.remaining)}</p><p className="text-xs text-muted mt-1">Remaining today</p></div>
      </div>
    </Card>
  );
}
