'use client';

import { useState, useMemo } from 'react';
import { positionSize } from '@/lib/finance/calculators';
import { Input, Label } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

// Contract specs are user-configurable, never assumed — different brokers/instruments
// have different tick sizes and tick values, and guessing wrong here would silently
// mis-size every position.
export function PositionSizeCalculator() {
  const [accountBalance, setAccountBalance] = useState(10000);
  const [riskPercent, setRiskPercent] = useState(1);
  const [entryPrice, setEntryPrice] = useState(0);
  const [stopLossPrice, setStopLossPrice] = useState(0);
  const [tickSize, setTickSize] = useState(0.25);
  const [tickValue, setTickValue] = useState(5);
  const [currency, setCurrency] = useState('USD');

  const result = useMemo(
    () => positionSize({ accountBalance, riskPercent, entryPrice, stopLossPrice, contract: { tickSize, tickValue } }),
    [accountBalance, riskPercent, entryPrice, stopLossPrice, tickSize, tickValue]
  );

  const fmt = (n: number) => n.toLocaleString(undefined, { style: 'currency', currency });

  return (
    <Card>
      <h2 className="font-medium mb-1">Position size calculator</h2>
      <p className="text-xs text-muted mb-4">Assumes constant tick value across the stop distance — verify against your broker's contract specs.</p>
      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="ps-balance">Account balance</Label>
          <Input id="ps-balance" type="number" value={accountBalance} onChange={(e) => setAccountBalance(Number(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="ps-currency">Currency</Label>
          <select id="ps-currency" value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="USD">USD</option><option value="EUR">EUR</option><option value="GBP">GBP</option><option value="INR">INR</option>
          </select>
        </div>
        <div>
          <Label htmlFor="ps-risk-pct">Risk %</Label>
          <Input id="ps-risk-pct" type="number" step="0.1" value={riskPercent} onChange={(e) => setRiskPercent(Number(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="ps-entry">Entry price</Label>
          <Input id="ps-entry" type="number" step="any" value={entryPrice} onChange={(e) => setEntryPrice(Number(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="ps-stop">Stop-loss price</Label>
          <Input id="ps-stop" type="number" step="any" value={stopLossPrice} onChange={(e) => setStopLossPrice(Number(e.target.value))} />
        </div>
        <div></div>
        <div>
          <Label htmlFor="ps-tick-size">Tick size</Label>
          <Input id="ps-tick-size" type="number" step="any" value={tickSize} onChange={(e) => setTickSize(Number(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="ps-tick-value">Tick value ({currency})</Label>
          <Input id="ps-tick-value" type="number" step="any" value={tickValue} onChange={(e) => setTickValue(Number(e.target.value))} />
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4 text-center border-t border-border pt-4">
        <div><p className="text-xl font-mono text-accent">{fmt(result.riskAmount)}</p><p className="text-xs text-muted mt-1">Risk amount</p></div>
        <div><p className="text-xl font-mono">{result.stopDistanceTicks.toFixed(1)}</p><p className="text-xs text-muted mt-1">Stop distance (ticks)</p></div>
        <div><p className="text-xl font-mono text-accent">{result.contracts}</p><p className="text-xs text-muted mt-1">Contracts</p></div>
      </div>
    </Card>
  );
}
