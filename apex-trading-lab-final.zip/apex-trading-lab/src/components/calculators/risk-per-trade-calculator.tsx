'use client';

import { useState, useMemo } from 'react';
import { riskPerTrade, percentRisk } from '@/lib/finance/calculators';
import { Input, Label } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

export function RiskPerTradeCalculator() {
  const [accountBalance, setAccountBalance] = useState(10000);
  const [riskPercent, setRiskPercent] = useState(1);
  const [currency, setCurrency] = useState('USD');

  const amount = useMemo(() => riskPerTrade(accountBalance, riskPercent), [accountBalance, riskPercent]);
  const backCheck = useMemo(() => percentRisk(amount, accountBalance), [amount, accountBalance]);

  return (
    <Card>
      <h2 className="font-medium mb-4">Risk-per-trade calculator</h2>
      <div className="grid md:grid-cols-3 gap-4">
        <div><Label htmlFor="rpt-balance">Account balance</Label><Input id="rpt-balance" type="number" value={accountBalance} onChange={(e) => setAccountBalance(Number(e.target.value))} /></div>
        <div>
          <Label htmlFor="rpt-currency">Currency</Label>
          <select id="rpt-currency" value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="USD">USD</option><option value="EUR">EUR</option><option value="GBP">GBP</option><option value="INR">INR</option>
          </select>
        </div>
        <div><Label htmlFor="rpt-pct">Risk %</Label><Input id="rpt-pct" type="number" step="0.1" value={riskPercent} onChange={(e) => setRiskPercent(Number(e.target.value))} /></div>
      </div>
      <div className="mt-6 text-center border-t border-border pt-4">
        <p className="text-2xl font-mono text-accent">{amount.toLocaleString(undefined, { style: 'currency', currency })}</p>
        <p className="text-xs text-muted mt-1">Amount to risk this trade ({backCheck.toFixed(2)}% of balance)</p>
      </div>
    </Card>
  );
}
