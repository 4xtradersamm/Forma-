'use client';

import { useState, useMemo } from 'react';
import { percentRisk } from '@/lib/finance/calculators';
import { Input, Label } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

export function PercentRiskCalculator() {
  const [riskAmount, setRiskAmount] = useState(100);
  const [accountBalance, setAccountBalance] = useState(10000);
  const pct = useMemo(() => percentRisk(riskAmount, accountBalance), [riskAmount, accountBalance]);

  return (
    <Card>
      <h2 className="font-medium mb-4">Percentage risk calculator</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <div><Label htmlFor="pr-amount">Risk amount</Label><Input id="pr-amount" type="number" value={riskAmount} onChange={(e) => setRiskAmount(Number(e.target.value))} /></div>
        <div><Label htmlFor="pr-balance">Account balance</Label><Input id="pr-balance" type="number" value={accountBalance} onChange={(e) => setAccountBalance(Number(e.target.value))} /></div>
      </div>
      <div className="mt-6 text-center border-t border-border pt-4">
        <p className="text-2xl font-mono text-accent">{pct.toFixed(2)}%</p>
        <p className="text-xs text-muted mt-1">Of account balance</p>
      </div>
    </Card>
  );
}
