'use client';

import { useState, useMemo } from 'react';
import { riskRewardRatio } from '@/lib/finance/calculators';
import { Input, Label } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

export function RiskRewardCalculator() {
  const [entryPrice, setEntryPrice] = useState(0);
  const [stopLossPrice, setStopLossPrice] = useState(0);
  const [takeProfitPrice, setTakeProfitPrice] = useState(0);

  const ratio = useMemo(() => riskRewardRatio({ entryPrice, stopLossPrice, takeProfitPrice }), [entryPrice, stopLossPrice, takeProfitPrice]);

  return (
    <Card>
      <h2 className="font-medium mb-4">Risk/reward calculator</h2>
      <div className="grid md:grid-cols-3 gap-4">
        <div><Label htmlFor="rr-entry">Entry price</Label><Input id="rr-entry" type="number" step="any" value={entryPrice} onChange={(e) => setEntryPrice(Number(e.target.value))} /></div>
        <div><Label htmlFor="rr-stop">Stop-loss price</Label><Input id="rr-stop" type="number" step="any" value={stopLossPrice} onChange={(e) => setStopLossPrice(Number(e.target.value))} /></div>
        <div><Label htmlFor="rr-target">Take-profit price</Label><Input id="rr-target" type="number" step="any" value={takeProfitPrice} onChange={(e) => setTakeProfitPrice(Number(e.target.value))} /></div>
      </div>
      <div className="mt-6 text-center border-t border-border pt-4">
        <p className="text-2xl font-mono text-accent">{ratio !== null ? `1 : ${ratio.toFixed(2)}` : '—'}</p>
        <p className="text-xs text-muted mt-1">Risk : Reward{ratio === null && ' (set a non-zero stop distance)'}</p>
      </div>
    </Card>
  );
}
