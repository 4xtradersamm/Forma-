'use client';

import { useActionState } from 'react';
import { updateProfileAction, type ActionState } from '@/app/actions/account';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const initialState: ActionState = {};

export function AccountForm({ defaultName }: { defaultName: string }) {
  const [state, formAction, isPending] = useActionState(updateProfileAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div>
        <Label htmlFor="display_name">Display name</Label>
        <Input id="display_name" name="display_name" defaultValue={defaultName} required />
        <FieldError>{state.fieldErrors?.display_name}</FieldError>
      </div>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>Save changes</Button>
    </form>
  );
}
