'use client';

import { useActionState } from 'react';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

type ActionState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean };
interface Defaults { title?: string; body?: string | null; video_url?: string | null; is_paid?: boolean; }

export function LessonForm({ defaults, action }: { defaults?: Defaults; action: (prev: ActionState, formData: FormData) => Promise<ActionState>; }) {
  const [state, formAction, isPending] = useActionState(action, {});
  return (
    <form action={formAction} className="space-y-4">
      <div><Label htmlFor="title">Title</Label><Input id="title" name="title" defaultValue={defaults?.title} required /><FieldError>{state.fieldErrors?.title}</FieldError></div>
      <div><Label htmlFor="video_url">Video embed URL (optional)</Label><Input id="video_url" name="video_url" defaultValue={defaults?.video_url ?? ''} placeholder="https://player.vimeo.com/video/..." /></div>
      <div>
        <Label htmlFor="body">Lesson content</Label>
        <textarea id="body" name="body" defaultValue={defaults?.body ?? ''} rows={12} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm font-mono" placeholder="Write the lesson content here. Plain text/markdown-style — rendered as-is for now." />
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_paid" value="true" defaultChecked={defaults?.is_paid} className="rounded border-border" />
        Paid lesson (requires an active membership)
      </label>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>Save lesson</Button>
    </form>
  );
}
