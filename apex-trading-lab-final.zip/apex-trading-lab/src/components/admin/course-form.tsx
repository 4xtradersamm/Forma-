'use client';

import { useActionState } from 'react';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

type ActionState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean };
interface Model { id: string; name: string; }
interface Defaults { title?: string; description?: string | null; model_id?: string | null; is_paid?: boolean; }

export function CourseForm({ models, defaults, action, submitLabel }: { models: Model[]; defaults?: Defaults; action: (prev: ActionState, formData: FormData) => Promise<ActionState>; submitLabel: string; }) {
  const [state, formAction, isPending] = useActionState(action, {});
  return (
    <form action={formAction} className="space-y-4">
      <div><Label htmlFor="title">Title</Label><Input id="title" name="title" defaultValue={defaults?.title} required /><FieldError>{state.fieldErrors?.title}</FieldError></div>
      <div>
        <Label htmlFor="description">Description</Label>
        <textarea id="description" name="description" defaultValue={defaults?.description ?? ''} rows={2} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      <div>
        <Label htmlFor="model_id">Model (optional — leave blank for general courses)</Label>
        <select id="model_id" name="model_id" defaultValue={defaults?.model_id ?? ''} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
          <option value="">General</option>
          {models.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_paid" value="true" defaultChecked={defaults?.is_paid} className="rounded border-border" />
        Paid course
      </label>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>{submitLabel}</Button>
    </form>
  );
}
