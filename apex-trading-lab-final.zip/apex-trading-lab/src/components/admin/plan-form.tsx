'use client';

import { useActionState } from 'react';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

type ActionState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean };
interface Defaults {
  name?: string; description?: string | null; interval?: string; price_cents?: number;
  currency?: string; provider?: string; provider_price_id?: string | null; features?: string[]; is_active?: boolean;
}

export function PlanForm({ defaults, action, submitLabel }: { defaults?: Defaults; action: (prev: ActionState, formData: FormData) => Promise<ActionState>; submitLabel: string; }) {
  const [state, formAction, isPending] = useActionState(action, {});

  return (
    <form action={formAction} className="space-y-4">
      <div><Label htmlFor="name">Plan name</Label><Input id="name" name="name" defaultValue={defaults?.name} required /><FieldError>{state.fieldErrors?.name}</FieldError></div>
      <div>
        <Label htmlFor="description">Description</Label>
        <textarea id="description" name="description" defaultValue={defaults?.description ?? ''} rows={2} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="interval">Billing interval</Label>
          <select id="interval" name="interval" defaultValue={defaults?.interval ?? 'monthly'} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="monthly">Monthly</option>
            <option value="annual">Annual</option>
          </select>
        </div>
        <div><Label htmlFor="price_cents">Price (in cents)</Label><Input id="price_cents" name="price_cents" type="number" defaultValue={defaults?.price_cents} required /><FieldError>{state.fieldErrors?.price_cents}</FieldError></div>
        <div><Label htmlFor="currency">Currency</Label><Input id="currency" name="currency" defaultValue={defaults?.currency ?? 'USD'} maxLength={3} required /></div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="provider">Payment provider</Label>
          <select id="provider" name="provider" defaultValue={defaults?.provider ?? 'stripe'} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="stripe">Stripe</option>
            <option value="razorpay">Razorpay</option>
          </select>
        </div>
        <div><Label htmlFor="provider_price_id">Provider price/plan ID</Label><Input id="provider_price_id" name="provider_price_id" defaultValue={defaults?.provider_price_id ?? ''} placeholder="price_... or plan_..." /></div>
      </div>
      <div>
        <Label htmlFor="features">Features (one per line)</Label>
        <textarea id="features" name="features" defaultValue={defaults?.features?.join('\n')} rows={4} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_active" value="true" defaultChecked={defaults?.is_active ?? true} className="rounded border-border" />
        Active (visible on the pricing page)
      </label>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>{submitLabel}</Button>
    </form>
  );
}
