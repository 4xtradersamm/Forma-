'use client';

import { useActionState } from 'react';
import { createAnnouncementAction, type ActionState } from '@/app/actions/announcements';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function AnnouncementForm() {
  const [state, formAction, isPending] = useActionState(createAnnouncementAction, {});

  return (
    <form action={formAction} className="space-y-4">
      <div><Label htmlFor="title">Title</Label><Input id="title" name="title" required /><FieldError>{state.fieldErrors?.title}</FieldError></div>
      <div>
        <Label htmlFor="body">Body</Label>
        <textarea id="body" name="body" rows={3} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" required />
        <FieldError>{state.fieldErrors?.body}</FieldError>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_paid_only" value="true" className="rounded border-border" />
        Paid members only
      </label>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" isLoading={isPending}>Publish announcement</Button>
    </form>
  );
}
