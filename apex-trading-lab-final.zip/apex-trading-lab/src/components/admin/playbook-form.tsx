'use client';

import { useActionState } from 'react';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface Model { id: string; slug: string; name: string; }

interface Defaults {
  model_id?: string;
  setup_name?: string;
  market_tags?: string[];
  timeframe_tags?: string[];
  session_tags?: string[];
  market_conditions?: string | null;
  prerequisites?: string | null;
  entry_conditions?: string | null;
  stop_loss_rules?: string | null;
  take_profit_rules?: string | null;
  invalidation_conditions?: string | null;
  risk_management_rules?: string | null;
  common_mistakes?: string | null;
  is_verified_rule?: boolean;
}

type ActionState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean };

function TextArea({ name, label, defaultValue }: { name: string; label: string; defaultValue?: string | null }) {
  return (
    <div>
      <Label htmlFor={name}>{label}</Label>
      <textarea
        id={name}
        name={name}
        defaultValue={defaultValue ?? ''}
        rows={3}
        className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm text-foreground placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/50"
        placeholder="Leave blank until the real rule is supplied — never invent one."
      />
    </div>
  );
}

export function PlaybookForm({
  models,
  defaults,
  action,
  submitLabel,
}: {
  models: Model[];
  defaults?: Defaults;
  action: (prev: ActionState, formData: FormData) => Promise<ActionState>;
  submitLabel: string;
}) {
  const [state, formAction, isPending] = useActionState(action, {});

  return (
    <form action={formAction} className="space-y-5">
      <div>
        <Label htmlFor="model_id">Model</Label>
        <select
          id="model_id"
          name="model_id"
          defaultValue={defaults?.model_id}
          className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm"
          required
        >
          <option value="">Select a model…</option>
          {models.map((m) => (
            <option key={m.id} value={m.id}>{m.name}</option>
          ))}
        </select>
        <FieldError>{state.fieldErrors?.model_id}</FieldError>
      </div>

      <div>
        <Label htmlFor="setup_name">Setup name</Label>
        <Input id="setup_name" name="setup_name" defaultValue={defaults?.setup_name} required />
        <FieldError>{state.fieldErrors?.setup_name}</FieldError>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="market_tags">Market tags (comma-separated)</Label>
          <Input id="market_tags" name="market_tags" defaultValue={defaults?.market_tags?.join(', ')} placeholder="NQ, ES" />
        </div>
        <div>
          <Label htmlFor="timeframe_tags">Timeframe tags</Label>
          <Input id="timeframe_tags" name="timeframe_tags" defaultValue={defaults?.timeframe_tags?.join(', ')} placeholder="5m, 15m" />
        </div>
        <div>
          <Label htmlFor="session_tags">Session tags</Label>
          <Input id="session_tags" name="session_tags" defaultValue={defaults?.session_tags?.join(', ')} placeholder="London, NY open" />
        </div>
      </div>

      <TextArea name="market_conditions" label="Market conditions" defaultValue={defaults?.market_conditions} />
      <TextArea name="prerequisites" label="Prerequisites" defaultValue={defaults?.prerequisites} />
      <TextArea name="entry_conditions" label="Entry conditions" defaultValue={defaults?.entry_conditions} />
      <TextArea name="stop_loss_rules" label="Stop-loss rules" defaultValue={defaults?.stop_loss_rules} />
      <TextArea name="take_profit_rules" label="Take-profit rules" defaultValue={defaults?.take_profit_rules} />
      <TextArea name="invalidation_conditions" label="Invalidation conditions" defaultValue={defaults?.invalidation_conditions} />
      <TextArea name="risk_management_rules" label="Risk-management rules" defaultValue={defaults?.risk_management_rules} />
      <TextArea name="common_mistakes" label="Common mistakes" defaultValue={defaults?.common_mistakes} />

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_verified_rule" value="true" defaultChecked={defaults?.is_verified_rule} className="rounded border-border" />
        These rules are final and verified (uncheck while still a placeholder)
      </label>

      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>{submitLabel}</Button>
    </form>
  );
}
