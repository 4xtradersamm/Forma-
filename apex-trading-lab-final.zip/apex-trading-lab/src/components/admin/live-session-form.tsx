'use client';

import { useActionState } from 'react';
import { createLiveSessionAction, type ActionState } from '@/app/actions/live-sessions';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function LiveSessionForm() {
  const [state, formAction, isPending] = useActionState(createLiveSessionAction, {});

  return (
    <form action={formAction} className="space-y-4">
      <div><Label htmlFor="title">Title</Label><Input id="title" name="title" required /><FieldError>{state.fieldErrors?.title}</FieldError></div>
      <div>
        <Label htmlFor="description">Description</Label>
        <textarea id="description" name="description" rows={2} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label htmlFor="starts_at">Starts at</Label><Input id="starts_at" name="starts_at" type="datetime-local" required /><FieldError>{state.fieldErrors?.starts_at}</FieldError></div>
        <div><Label htmlFor="ends_at">Ends at</Label><Input id="ends_at" name="ends_at" type="datetime-local" /></div>
      </div>
      <div><Label htmlFor="join_url">Join URL (secure link, shown only to authorized members)</Label><Input id="join_url" name="join_url" placeholder="https://..." /></div>
      <div><Label htmlFor="replay_url">Replay URL (optional, fill in after the session)</Label><Input id="replay_url" name="replay_url" placeholder="https://..." /></div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_paid_only" value="true" defaultChecked className="rounded border-border" />
        Paid members only
      </label>
      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      <Button type="submit" isLoading={isPending}>Schedule session</Button>
    </form>
  );
}
