import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { PrintChecklistButton } from '@/components/models/print-checklist-button';

const FIELDS: Array<{ key: string; label: string }> = [
  { key: 'market_conditions', label: 'Market conditions' },
  { key: 'prerequisites', label: 'Prerequisites' },
  { key: 'entry_conditions', label: 'Entry conditions' },
  { key: 'stop_loss_rules', label: 'Stop-loss rules' },
  { key: 'take_profit_rules', label: 'Take-profit rules' },
  { key: 'invalidation_conditions', label: 'Invalidation conditions' },
  { key: 'risk_management_rules', label: 'Risk-management rules' },
  { key: 'common_mistakes', label: 'Common mistakes' },
];

export async function PlaybookDetail({ id }: { id: string }) {
  const supabase = createClient();
  const { data: playbook } = await supabase
    .from('playbooks')
    .select('*')
    .eq('id', id)
    .eq('status', 'published')
    .maybeSingle();

  if (!playbook) notFound();

  return (
    <div className="mx-auto max-w-3xl px-6 py-16" id="playbook-printable">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">{playbook.setup_name}</h1>
          {!playbook.is_verified_rule && (
            <span className="inline-block mt-2 text-xs border border-warning/40 text-warning rounded-full px-2 py-0.5">
              Placeholder — not yet verified as final
            </span>
          )}
        </div>
        <PrintChecklistButton />
      </div>

      <div className="mt-8 space-y-6">
        {FIELDS.map(({ key, label }) => {
          const value = (playbook as Record<string, unknown>)[key] as string | null;
          return (
            <div key={key}>
              <h2 className="font-medium">{label}</h2>
              <p className="mt-1 text-sm text-muted whitespace-pre-line">
                {value || '[Not yet documented]'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
