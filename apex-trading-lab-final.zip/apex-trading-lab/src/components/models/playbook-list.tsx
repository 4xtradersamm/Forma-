import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';

export async function PlaybookList({ slug, name }: { slug: 'qt' | 'gxt' | 'ttfm'; name: string }) {
  const supabase = createClient();
  const { data: model } = await supabase.from('models').select('id').eq('slug', slug).maybeSingle();

  const { data: playbooks } = model
    ? await supabase
        .from('playbooks')
        .select('id, setup_name, market_tags, timeframe_tags, is_verified_rule')
        .eq('model_id', model.id)
        .eq('status', 'published')
        .order('sort_order')
    : { data: [] };

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <p className="label-muted">{name} setup library</p>
      <h1 className="text-3xl font-semibold mt-2">Playbooks</h1>

      <div className="mt-8 space-y-3">
        {playbooks && playbooks.length > 0 ? (
          playbooks.map((p) => (
            <Link key={p.id} href={`/models/${slug}/playbooks/${p.id}`}>
              <Card className="hover:border-accent/50 transition-colors">
                <div className="flex items-center justify-between">
                  <p className="font-medium">{p.setup_name}</p>
                  {!p.is_verified_rule && (
                    <span className="text-xs border border-warning/40 text-warning rounded-full px-2 py-0.5">placeholder</span>
                  )}
                </div>
                {(p.market_tags?.length || p.timeframe_tags?.length) ? (
                  <p className="text-xs text-muted mt-2">
                    {[...(p.market_tags ?? []), ...(p.timeframe_tags ?? [])].join(' · ')}
                  </p>
                ) : null}
              </Card>
            </Link>
          ))
        ) : (
          <p className="text-sm text-muted">No published setups yet for {name}.</p>
        )}
      </div>
    </div>
  );
}
