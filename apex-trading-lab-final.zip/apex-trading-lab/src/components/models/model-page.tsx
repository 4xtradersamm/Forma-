// Shared template for the QT / GXT / TTFM public model pages.
// Rules are placeholders until the founder supplies verified content —
// this component never invents entry/exit logic.
import Link from 'next/link';

export function ModelPage({ name }: { name: 'QT' | 'GXT' | 'TTFM' }) {
  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <p className="label-muted">Model</p>
      <h1 className="text-4xl font-semibold mt-2">{name}</h1>

      <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs text-warning">
        Placeholder content — verified {name} rules not yet published
      </div>

      <section className="mt-10 grid md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="font-medium">Overview</h2>
          <p className="mt-2 text-sm text-muted">
            [Placeholder] A written overview of the {name} model will appear here once supplied by the founder.
          </p>
        </div>
        <div className="card">
          <h2 className="font-medium">Prerequisites</h2>
          <p className="mt-2 text-sm text-muted">
            [Placeholder] Prerequisite knowledge or completed lessons for {name}.
          </p>
        </div>
      </section>

      <section className="mt-6 grid md:grid-cols-3 gap-6">
        <div className="card">
          <h2 className="font-medium">Lessons</h2>
          <p className="mt-2 text-sm text-muted">No lessons published yet.</p>
        </div>
        <Link href={`/models/${name.toLowerCase()}/playbooks`} className="card hover:border-accent/50 transition-colors">
          <h2 className="font-medium">Setup library</h2>
          <p className="mt-2 text-sm text-muted">View the {name} playbook library &rarr;</p>
        </Link>
        <div className="card">
          <h2 className="font-medium">Example charts</h2>
          <p className="mt-2 text-sm text-muted">Annotated charts will appear here once uploaded.</p>
        </div>
      </section>

      <div className="mt-10">
        <Link href="/pricing" className="btn-primary">Unlock full {name} playbooks</Link>
      </div>
    </div>
  );
}
