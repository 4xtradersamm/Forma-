'use client';

import { Button } from '@/components/ui/button';

export function PrintChecklistButton() {
  return (
    <Button variant="secondary" onClick={() => window.print()} className="shrink-0 print:hidden">
      Print checklist
    </Button>
  );
}
