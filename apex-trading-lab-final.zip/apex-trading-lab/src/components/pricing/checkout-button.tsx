'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export function CheckoutButton({ planId, isSignedIn }: { planId: string; isSignedIn: boolean }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleClick() {
    if (!isSignedIn) {
      router.push(`/sign-in?redirect=/pricing`);
      return;
    }

    setLoading(true);
    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan_id: planId }),
    });
    const data = await res.json();

    if (!res.ok) {
      setLoading(false);
      alert(data.error ?? 'Checkout failed to start.');
      return;
    }

    if (data.provider === 'stripe') {
      window.location.href = data.url;
      return;
    }

    if (data.provider === 'razorpay') {
      const loaded = await loadRazorpayScript();
      setLoading(false);
      if (!loaded) {
        alert('Could not load the payment widget. Check your connection and try again.');
        return;
      }
      const rzp = new window.Razorpay({
        key: data.keyId,
        subscription_id: data.subscriptionId,
        name: 'Apex Trading Lab',
        description: data.planName,
        handler: function () {
          // The webhook is the source of truth for activation; this just gets the
          // user back to a page that reflects it once Razorpay's webhook lands.
          router.push('/dashboard/account?checkout=processing');
        },
        theme: { color: '#10b981' },
      });
      rzp.open();
      return;
    }
  }

  return (
    <Button onClick={handleClick} isLoading={loading} className="w-full mt-4">
      Subscribe
    </Button>
  );
}
