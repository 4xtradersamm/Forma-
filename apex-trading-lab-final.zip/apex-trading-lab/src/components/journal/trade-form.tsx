'use client';

import { useActionState } from 'react';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScreenshotUpload } from '@/components/journal/screenshot-upload';

type ActionState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean };

interface Defaults {
  instrument?: string;
  market?: string | null;
  traded_at?: string;
  model?: string;
  direction?: string;
  entry_price?: number | null;
  stop_loss_price?: number | null;
  take_profit_price?: number | null;
  exit_price?: number | null;
  position_size?: number | null;
  risk_amount?: number | null;
  gross_pnl?: number | null;
  fees?: number | null;
  r_multiple?: number | null;
  setup_followed?: string | null;
  emotional_state?: string | null;
  mistakes?: string | null;
  notes?: string | null;
  tags?: string[];
  is_open?: boolean;
  screenshot_before_url?: string | null;
  screenshot_after_url?: string | null;
  playbook_id?: string | null;
}

interface PlaybookOption { id: string; label: string; }

export function TradeForm({
  userId,
  defaults,
  action,
  submitLabel,
  playbookOptions = [],
}: {
  userId: string;
  defaults?: Defaults;
  action: (prev: ActionState, formData: FormData) => Promise<ActionState>;
  submitLabel: string;
  playbookOptions?: PlaybookOption[];
}) {
  const [state, formAction, isPending] = useActionState(action, {});

  // datetime-local input needs "YYYY-MM-DDTHH:mm"
  const tradedAtDefault = defaults?.traded_at ? new Date(defaults.traded_at).toISOString().slice(0, 16) : '';

  return (
    <form action={formAction} className="space-y-5">
      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="instrument">Instrument</Label>
          <Input id="instrument" name="instrument" defaultValue={defaults?.instrument} placeholder="NQ" required />
          <FieldError>{state.fieldErrors?.instrument}</FieldError>
        </div>
        <div>
          <Label htmlFor="market">Market</Label>
          <Input id="market" name="market" defaultValue={defaults?.market ?? ''} placeholder="Futures" />
        </div>
        <div>
          <Label htmlFor="traded_at">Date &amp; time</Label>
          <Input id="traded_at" name="traded_at" type="datetime-local" defaultValue={tradedAtDefault} required />
          <FieldError>{state.fieldErrors?.traded_at}</FieldError>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="model">Model</Label>
          <select id="model" name="model" defaultValue={defaults?.model ?? 'OTHER'} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" required>
            <option value="QT">QT</option>
            <option value="GXT">GXT</option>
            <option value="TTFM">TTFM</option>
            <option value="OTHER">Other</option>
          </select>
        </div>
        <div>
          <Label htmlFor="direction">Direction</Label>
          <select id="direction" name="direction" defaultValue={defaults?.direction ?? 'LONG'} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" required>
            <option value="LONG">Long</option>
            <option value="SHORT">Short</option>
          </select>
        </div>
        <div>
          <Label htmlFor="setup_followed">Setup followed?</Label>
          <select id="setup_followed" name="setup_followed" defaultValue={defaults?.setup_followed ?? ''} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
            <option value="">—</option>
            <option value="YES">Yes</option>
            <option value="PARTIAL">Partial</option>
            <option value="NO">No</option>
          </select>
        </div>
      </div>

      <div>
        <Label htmlFor="playbook_id">Setup (playbook)</Label>
        <select id="playbook_id" name="playbook_id" defaultValue={defaults?.playbook_id ?? ''} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm">
          <option value="">— None / not tied to a published setup —</option>
          {playbookOptions.map((p) => (
            <option key={p.id} value={p.id}>{p.label}</option>
          ))}
        </select>
        <p className="mt-1 text-xs text-muted">Linking a trade to a setup powers the "results by setup" analytics.</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <div><Label htmlFor="entry_price">Entry price</Label><Input id="entry_price" name="entry_price" type="number" step="any" defaultValue={defaults?.entry_price ?? ''} /></div>
        <div><Label htmlFor="stop_loss_price">Stop-loss</Label><Input id="stop_loss_price" name="stop_loss_price" type="number" step="any" defaultValue={defaults?.stop_loss_price ?? ''} /></div>
        <div><Label htmlFor="take_profit_price">Take-profit</Label><Input id="take_profit_price" name="take_profit_price" type="number" step="any" defaultValue={defaults?.take_profit_price ?? ''} /></div>
        <div><Label htmlFor="exit_price">Exit price</Label><Input id="exit_price" name="exit_price" type="number" step="any" defaultValue={defaults?.exit_price ?? ''} /></div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <div><Label htmlFor="position_size">Position size</Label><Input id="position_size" name="position_size" type="number" step="any" defaultValue={defaults?.position_size ?? ''} /></div>
        <div><Label htmlFor="risk_amount">Risk amount</Label><Input id="risk_amount" name="risk_amount" type="number" step="any" defaultValue={defaults?.risk_amount ?? ''} /></div>
        <div><Label htmlFor="gross_pnl">Gross P&amp;L</Label><Input id="gross_pnl" name="gross_pnl" type="number" step="any" defaultValue={defaults?.gross_pnl ?? ''} /></div>
        <div><Label htmlFor="fees">Fees</Label><Input id="fees" name="fees" type="number" step="any" defaultValue={defaults?.fees ?? 0} /></div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div><Label htmlFor="r_multiple">R-multiple</Label><Input id="r_multiple" name="r_multiple" type="number" step="any" defaultValue={defaults?.r_multiple ?? ''} /></div>
        <div><Label htmlFor="tags">Tags (comma-separated)</Label><Input id="tags" name="tags" defaultValue={defaults?.tags?.join(', ')} placeholder="breakout, news" /></div>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="is_open" value="true" defaultChecked={defaults?.is_open} className="rounded border-border" />
        This trade is still open
      </label>

      <div className="grid md:grid-cols-2 gap-4">
        <ScreenshotUpload name="screenshot_before_url" label="Screenshot before entry" userId={userId} defaultPath={defaults?.screenshot_before_url} />
        <ScreenshotUpload name="screenshot_after_url" label="Screenshot after exit" userId={userId} defaultPath={defaults?.screenshot_after_url} />
      </div>

      <div>
        <Label htmlFor="emotional_state">Emotional state</Label>
        <Input id="emotional_state" name="emotional_state" defaultValue={defaults?.emotional_state ?? ''} placeholder="Calm, confident, rushed…" />
      </div>
      <div>
        <Label htmlFor="mistakes">Mistakes</Label>
        <textarea id="mistakes" name="mistakes" defaultValue={defaults?.mistakes ?? ''} rows={2} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>
      <div>
        <Label htmlFor="notes">Notes</Label>
        <textarea id="notes" name="notes" defaultValue={defaults?.notes ?? ''} rows={3} className="w-full rounded-lg border border-border bg-surface px-4 py-2.5 text-sm" />
      </div>

      {state.error && <p className="text-sm text-danger">{state.error}</p>}
      {state.success && <p className="text-sm text-accent">Saved.</p>}
      <Button type="submit" isLoading={isPending}>{submitLabel}</Button>
    </form>
  );
}
