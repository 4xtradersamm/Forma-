'use client';

import Papa from 'papaparse';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function CsvExportButton() {
  const [loading, setLoading] = useState(false);

  async function handleExport() {
    setLoading(true);
    const supabase = createClient();
    // RLS scopes this to the signed-in user's own trades automatically.
    const { data: trades, error } = await supabase.from('journal_trades').select('*').order('traded_at', { ascending: false });
    setLoading(false);
    if (error || !trades) {
      alert('Export failed: ' + (error?.message ?? 'unknown error'));
      return;
    }
    const csv = Papa.unparse(trades);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `journal-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Button variant="secondary" onClick={handleExport} isLoading={loading}>
      Export CSV
    </Button>
  );
}
