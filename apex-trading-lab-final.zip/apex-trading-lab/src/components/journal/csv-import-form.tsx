'use client';

import { useState } from 'react';
import Papa from 'papaparse';
import { tradeSchema, toTradeRow } from '@/lib/validation/journal';
import { bulkImportTradesAction } from '@/app/actions/journal';
import { Button } from '@/components/ui/button';

// Expected CSV headers match the trade-form field names (instrument, traded_at, model,
// direction, entry_price, ...). Rows that fail validation are skipped and reported —
// nothing is silently coerced into fake data.
export function CsvImportForm() {
  const [status, setStatus] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  function handleFile(file: File) {
    setImporting(true);
    setStatus(null);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        const validRows: ReturnType<typeof toTradeRow>[] = [];
        let skipped = 0;
        for (const row of results.data as Record<string, string>[]) {
          const parsed = tradeSchema.safeParse(row);
          if (parsed.success) {
            validRows.push(toTradeRow(parsed.data));
          } else {
            skipped++;
          }
        }
        if (validRows.length === 0) {
          setStatus(`No valid rows found. ${skipped} row(s) skipped — check column headers match the export format.`);
          setImporting(false);
          return;
        }
        const result = await bulkImportTradesAction(validRows);
        setImporting(false);
        if (result.error) {
          setStatus(`Import failed: ${result.error}`);
        } else {
          setStatus(`Imported ${result.imported} trade(s)${skipped ? `, skipped ${skipped} invalid row(s)` : ''}.`);
        }
      },
    });
  }

  return (
    <div>
      <input
        type="file"
        accept=".csv"
        disabled={importing}
        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        className="text-sm text-muted file:mr-3 file:rounded-lg file:border file:border-border file:bg-surface file:px-3 file:py-1.5 file:text-sm file:text-foreground"
      />
      {importing && <p className="text-xs text-muted mt-1">Importing…</p>}
      {status && <p className="text-xs text-muted mt-1">{status}</p>}
    </div>
  );
}
