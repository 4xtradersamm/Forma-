'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Label } from '@/components/ui/input';

// Uploads to the private `journal-screenshots` bucket under `${userId}/...` — the
// storage RLS policies (0003_storage.sql) only allow a user to read/write their own
// folder, so this path convention is load-bearing, not cosmetic.
export function ScreenshotUpload({
  name,
  label,
  userId,
  defaultPath,
}: {
  name: string;
  label: string;
  userId: string;
  defaultPath?: string | null;
}) {
  const [path, setPath] = useState(defaultPath ?? '');
  const [previewName, setPreviewName] = useState<string | null>(defaultPath ? defaultPath.split('/').pop()! : null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(file: File) {
    if (file.size > 5 * 1024 * 1024) {
      setError('Max file size is 5MB.');
      return;
    }
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      setError('Only PNG, JPEG, or WEBP images are allowed.');
      return;
    }
    setError(null);
    setUploading(true);
    const supabase = createClient();
    const objectPath = `${userId}/${crypto.randomUUID()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from('journal-screenshots').upload(objectPath, file, {
      contentType: file.type,
      upsert: false,
    });
    setUploading(false);
    if (uploadError) {
      setError(uploadError.message);
      return;
    }
    setPath(objectPath);
    setPreviewName(file.name);
  }

  return (
    <div>
      <Label htmlFor={name}>{label}</Label>
      <input type="hidden" name={name} value={path} />
      <input
        type="file"
        accept="image/png,image/jpeg,image/webp"
        disabled={uploading}
        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        className="text-sm text-muted file:mr-3 file:rounded-lg file:border file:border-border file:bg-surface file:px-3 file:py-1.5 file:text-sm file:text-foreground"
      />
      {uploading && <p className="text-xs text-muted mt-1">Uploading…</p>}
      {previewName && !uploading && <p className="text-xs text-accent mt-1">Attached: {previewName}</p>}
      {error && <p className="text-xs text-danger mt-1">{error}</p>}
    </div>
  );
}
