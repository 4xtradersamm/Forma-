'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function EquityCurveChart({ data }: { data: { trade: number; equity: number }[] }) {
  if (data.length === 0) return <p className="text-sm text-muted">No closed trades yet.</p>;
  return (
    <ResponsiveContainer width="100%" height={280}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#232326" />
        <XAxis dataKey="trade" stroke="#9a9aa2" fontSize={12} tickLine={false} />
        <YAxis stroke="#9a9aa2" fontSize={12} tickLine={false} />
        <Tooltip contentStyle={{ background: '#111113', border: '1px solid #232326', borderRadius: 8, fontSize: 12 }} />
        <Line type="monotone" dataKey="equity" stroke="#10b981" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
