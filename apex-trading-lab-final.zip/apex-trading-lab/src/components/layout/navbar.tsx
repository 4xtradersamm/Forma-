import Link from 'next/link';

const MODEL_LINKS = [
  { href: '/models/qt', label: 'QT' },
  { href: '/models/gxt', label: 'GXT' },
  { href: '/models/ttfm', label: 'TTFM' },
];

export function Navbar() {
  return (
    <header className="border-b border-border bg-background/95 backdrop-blur sticky top-0 z-40">
      <nav className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-semibold tracking-tight">
          Apex <span className="text-accent">Trading Lab</span>
        </Link>
        <div className="hidden md:flex items-center gap-6 text-sm text-muted">
          {MODEL_LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-foreground transition-colors">
              {l.label}
            </Link>
          ))}
          <Link href="/learn" className="hover:text-foreground transition-colors">Learn</Link>
          <Link href="/community" className="hover:text-foreground transition-colors">Community</Link>
          <Link href="/pricing" className="hover:text-foreground transition-colors">Pricing</Link>
          <Link href="/about" className="hover:text-foreground transition-colors">About</Link>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/sign-in" className="btn-secondary text-sm px-4 py-2">Sign in</Link>
          <Link href="/sign-up" className="btn-primary text-sm px-4 py-2">Sign up</Link>
        </div>
      </nav>
    </header>
  );
}
