import Link from 'next/link';

export function Footer() {
  return (
    <footer className="border-t border-border mt-24">
      <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row justify-between gap-6 text-sm text-muted">
        <p>&copy; {new Date().getFullYear()} Apex Trading Lab. All rights reserved.</p>
        <div className="flex gap-6">
          <Link href="/legal/terms" className="hover:text-foreground">Terms</Link>
          <Link href="/legal/privacy" className="hover:text-foreground">Privacy</Link>
          <Link href="/legal/risk-disclosure" className="hover:text-foreground">Risk Disclosure</Link>
          <Link href="/legal/cancellation" className="hover:text-foreground">Cancellation Policy</Link>
        </div>
      </div>
      <p className="text-center text-xs text-muted pb-6 px-6">
        Trading involves substantial risk of loss. Past performance does not guarantee future results.
      </p>
    </footer>
  );
}
