'use client';

import { useState, useTransition } from 'react';
import { markLessonCompleteAction, toggleBookmarkAction } from '@/app/actions/education';
import { Button } from '@/components/ui/button';

export function LessonActions({
  lessonId,
  courseId,
  initiallyCompleted,
  initiallyBookmarked,
}: {
  lessonId: string;
  courseId: string;
  initiallyCompleted: boolean;
  initiallyBookmarked: boolean;
}) {
  const [completed, setCompleted] = useState(initiallyCompleted);
  const [bookmarked, setBookmarked] = useState(initiallyBookmarked);
  const [isPending, startTransition] = useTransition();

  return (
    <div className="flex items-center gap-3">
      <Button
        variant={completed ? 'secondary' : 'primary'}
        isLoading={isPending}
        onClick={() =>
          startTransition(async () => {
            await markLessonCompleteAction(lessonId, courseId);
            setCompleted(true);
          })
        }
      >
        {completed ? 'Completed ✓' : 'Mark complete'}
      </Button>
      <Button
        variant="secondary"
        onClick={() =>
          startTransition(async () => {
            await toggleBookmarkAction(lessonId, courseId, bookmarked);
            setBookmarked((b) => !b);
          })
        }
      >
        {bookmarked ? 'Bookmarked ★' : 'Bookmark'}
      </Button>
    </div>
  );
}
