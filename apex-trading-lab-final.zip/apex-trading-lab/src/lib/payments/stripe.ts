import Stripe from 'stripe';

// Single shared server-side Stripe client. Never import this from a Client Component —
// STRIPE_SECRET_KEY must stay server-only.
export function getStripeClient() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error('STRIPE_SECRET_KEY is not set.');
  return new Stripe(key, { apiVersion: '2024-06-20' });
}
