import { z } from 'zod';

export const planSchema = z.object({
  name: z.string().min(1, 'Name is required').max(60),
  description: z.string().optional(),
  interval: z.enum(['monthly', 'annual']),
  price_cents: z.coerce.number().int().min(0, 'Price cannot be negative'),
  currency: z.string().length(3, 'Use a 3-letter currency code').default('USD'),
  provider: z.enum(['stripe', 'razorpay']),
  provider_price_id: z.string().optional(),
  features: z.string().optional(), // one per line in the form
  is_active: z.coerce.boolean().optional(),
});

export type PlanInput = z.infer<typeof planSchema>;

export function toPlanRow(input: PlanInput) {
  return {
    name: input.name,
    description: input.description || null,
    interval: input.interval,
    price_cents: input.price_cents,
    currency: input.currency.toUpperCase(),
    provider: input.provider,
    provider_price_id: input.provider_price_id || null,
    features: input.features ? input.features.split('\n').map((f) => f.trim()).filter(Boolean) : [],
    is_active: input.is_active ?? true,
  };
}
