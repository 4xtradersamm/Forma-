import { z } from 'zod';

export const playbookSchema = z.object({
  model_id: z.string().uuid('Select a model'),
  setup_name: z.string().min(1, 'Setup name is required').max(120),
  market_tags: z.string().optional(),      // comma-separated in the form, split before saving
  timeframe_tags: z.string().optional(),
  session_tags: z.string().optional(),
  market_conditions: z.string().optional(),
  prerequisites: z.string().optional(),
  entry_conditions: z.string().optional(),
  stop_loss_rules: z.string().optional(),
  take_profit_rules: z.string().optional(),
  invalidation_conditions: z.string().optional(),
  risk_management_rules: z.string().optional(),
  common_mistakes: z.string().optional(),
  is_verified_rule: z.coerce.boolean().optional(),
});

export type PlaybookInput = z.infer<typeof playbookSchema>;

function splitTags(value?: string): string[] {
  if (!value) return [];
  return value.split(',').map((s) => s.trim()).filter(Boolean);
}

export function toPlaybookRow(input: PlaybookInput) {
  return {
    model_id: input.model_id,
    setup_name: input.setup_name,
    market_tags: splitTags(input.market_tags),
    timeframe_tags: splitTags(input.timeframe_tags),
    session_tags: splitTags(input.session_tags),
    market_conditions: input.market_conditions || null,
    prerequisites: input.prerequisites || null,
    entry_conditions: input.entry_conditions || null,
    stop_loss_rules: input.stop_loss_rules || null,
    take_profit_rules: input.take_profit_rules || null,
    invalidation_conditions: input.invalidation_conditions || null,
    risk_management_rules: input.risk_management_rules || null,
    common_mistakes: input.common_mistakes || null,
    is_verified_rule: input.is_verified_rule ?? false,
  };
}
