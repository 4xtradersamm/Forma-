import { z } from 'zod';

export const tradeSchema = z.object({
  instrument: z.string().min(1, 'Instrument is required').max(20),
  market: z.string().max(40).optional(),
  traded_at: z.string().min(1, 'Date/time is required'), // datetime-local string
  model: z.enum(['QT', 'GXT', 'TTFM', 'OTHER']),
  direction: z.enum(['LONG', 'SHORT']),
  entry_price: z.coerce.number().optional(),
  stop_loss_price: z.coerce.number().optional(),
  take_profit_price: z.coerce.number().optional(),
  exit_price: z.coerce.number().optional(),
  position_size: z.coerce.number().optional(),
  risk_amount: z.coerce.number().optional(),
  gross_pnl: z.coerce.number().optional(),
  fees: z.coerce.number().default(0),
  r_multiple: z.coerce.number().optional(),
  setup_followed: z.enum(['YES', 'NO', 'PARTIAL']).optional(),
  emotional_state: z.string().max(200).optional(),
  mistakes: z.string().max(1000).optional(),
  notes: z.string().max(2000).optional(),
  tags: z.string().optional(), // comma-separated in the form
  is_open: z.coerce.boolean().optional(),
  playbook_id: z.string().uuid().optional().or(z.literal('')),
});

export type TradeInput = z.infer<typeof tradeSchema>;

export function toTradeRow(input: TradeInput) {
  return {
    instrument: input.instrument.toUpperCase(),
    market: input.market || null,
    traded_at: new Date(input.traded_at).toISOString(),
    model: input.model,
    direction: input.direction,
    entry_price: input.entry_price ?? null,
    stop_loss_price: input.stop_loss_price ?? null,
    take_profit_price: input.take_profit_price ?? null,
    exit_price: input.exit_price ?? null,
    position_size: input.position_size ?? null,
    risk_amount: input.risk_amount ?? null,
    gross_pnl: input.gross_pnl ?? null,
    fees: input.fees ?? 0,
    r_multiple: input.r_multiple ?? null,
    setup_followed: input.setup_followed ?? null,
    emotional_state: input.emotional_state || null,
    mistakes: input.mistakes || null,
    notes: input.notes || null,
    tags: input.tags ? input.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
    is_open: input.is_open ?? false,
    playbook_id: input.playbook_id || null,
  };
}
