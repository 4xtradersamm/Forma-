import { z } from 'zod';

export const backtestSessionSchema = z.object({
  model: z.enum(['QT', 'GXT', 'TTFM', 'OTHER']),
  instrument: z.string().min(1, 'Instrument is required').max(20),
  timeframe: z.string().min(1, 'Timeframe is required').max(20),
  date_range_start: z.string().optional(),
  date_range_end: z.string().optional(),
});

export const backtestTradeSchema = z.object({
  setup_date: z.string().min(1, 'Date is required'),
  entry_price: z.coerce.number().optional(),
  stop_loss_price: z.coerce.number().optional(),
  take_profit_price: z.coerce.number().optional(),
  outcome: z.enum(['win', 'loss', 'breakeven', 'invalid']),
  r_multiple: z.coerce.number().optional(),
  all_rules_satisfied: z.coerce.boolean().optional(),
  chart_image_url: z.string().optional(),
  notes: z.string().max(1000).optional(),
});

export type BacktestSessionInput = z.infer<typeof backtestSessionSchema>;
export type BacktestTradeInput = z.infer<typeof backtestTradeSchema>;
