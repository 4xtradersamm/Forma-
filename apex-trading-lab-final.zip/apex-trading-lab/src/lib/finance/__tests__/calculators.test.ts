import { describe, it, expect } from 'vitest';
import { positionSize, riskRewardRatio, riskPerTrade, percentRisk, dailyLossLimitReached } from '../calculators';

describe('positionSize', () => {
  it('sizes a position correctly for a normal stop distance', () => {
    // $10k account, 1% risk = $100. Entry 100, stop 99 = 1pt = 4 ticks at 0.25.
    // $5/tick * 4 ticks = $20/contract risk. floor(100/20) = 5 contracts.
    const result = positionSize({
      accountBalance: 10000, riskPercent: 1, entryPrice: 100, stopLossPrice: 99,
      contract: { tickSize: 0.25, tickValue: 5 },
    });
    expect(result.riskAmount).toBe(100);
    expect(result.stopDistanceTicks).toBe(4);
    expect(result.contracts).toBe(5);
  });

  it('floors to 0 contracts rather than over-risking when the stop is too wide', () => {
    const result = positionSize({
      accountBalance: 10000, riskPercent: 1, entryPrice: 20000, stopLossPrice: 19990,
      contract: { tickSize: 0.25, tickValue: 5 },
    });
    expect(result.contracts).toBe(0);
  });

  it('handles a zero stop distance without dividing by zero', () => {
    const result = positionSize({
      accountBalance: 10000, riskPercent: 1, entryPrice: 100, stopLossPrice: 100,
      contract: { tickSize: 0.25, tickValue: 5 },
    });
    expect(result.contracts).toBe(0);
    expect(Number.isFinite(result.stopDistanceTicks)).toBe(true);
  });
});

describe('riskRewardRatio', () => {
  it('computes a standard ratio', () => {
    expect(riskRewardRatio({ entryPrice: 100, stopLossPrice: 95, takeProfitPrice: 110 })).toBe(2);
  });
  it('returns null when risk distance is zero', () => {
    expect(riskRewardRatio({ entryPrice: 100, stopLossPrice: 100, takeProfitPrice: 110 })).toBeNull();
  });
});

describe('riskPerTrade / percentRisk', () => {
  it('are inverses of each other', () => {
    const amount = riskPerTrade(10000, 2);
    expect(amount).toBe(200);
    expect(percentRisk(amount, 10000)).toBe(2);
  });
  it('percentRisk handles a zero balance without dividing by zero', () => {
    expect(percentRisk(100, 0)).toBe(0);
  });
});

describe('dailyLossLimitReached', () => {
  it('flags the limit as reached once realized loss meets it', () => {
    const result = dailyLossLimitReached(300, 10000, 3);
    expect(result.limit).toBe(300);
    expect(result.reached).toBe(true);
    expect(result.remaining).toBe(0);
  });
  it('reports remaining budget before the limit is hit', () => {
    const result = dailyLossLimitReached(100, 10000, 3);
    expect(result.reached).toBe(false);
    expect(result.remaining).toBe(200);
  });
});
