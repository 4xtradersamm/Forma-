import { describe, it, expect } from 'vitest';
import { winRate, averageWin, averageLoss, profitFactor, expectancy, averageRMultiple, equityCurve, maxDrawdown } from '../analytics';

const trades = [
  { netPnl: 100, rMultiple: 2 },
  { netPnl: -50, rMultiple: -1 },
  { netPnl: 200, rMultiple: 3 },
  { netPnl: -100, rMultiple: -1 },
];

describe('winRate', () => {
  it('computes the percentage of winning trades', () => expect(winRate(trades)).toBe(50));
  it('returns 0 for an empty dataset rather than NaN', () => expect(winRate([])).toBe(0));
});

describe('averageWin / averageLoss', () => {
  it('computes correctly', () => {
    expect(averageWin(trades)).toBe(150);
    expect(averageLoss(trades)).toBe(-75);
  });
  it('return 0 when there are no wins or no losses', () => {
    expect(averageWin([{ netPnl: -10, rMultiple: null }])).toBe(0);
    expect(averageLoss([{ netPnl: 10, rMultiple: null }])).toBe(0);
  });
});

describe('profitFactor', () => {
  it('computes gross profit / gross loss', () => expect(profitFactor(trades)).toBe(2));
  it('returns Infinity for all-winning trades, not a crash', () => {
    expect(profitFactor([{ netPnl: 100, rMultiple: null }])).toBe(Infinity);
  });
  it('returns 0 for all-losing trades (no division by zero)', () => {
    expect(profitFactor([{ netPnl: -100, rMultiple: null }])).toBe(0);
  });
  it('returns 0 for an empty dataset', () => expect(profitFactor([])).toBe(0));
});

describe('expectancy', () => {
  it('computes expected value per trade', () => {
    // wr=0.5, avgWin=150, avgLoss=-75 => 0.5*150 + 0.5*-75 = 37.5
    expect(expectancy(trades)).toBe(37.5);
  });
  it('returns 0 for an empty dataset', () => expect(expectancy([])).toBe(0));
});

describe('averageRMultiple', () => {
  it('averages only trades with a recorded R-multiple', () => {
    expect(averageRMultiple(trades)).toBe(0.75); // (2-1+3-1)/4
  });
  it('returns null when no trade has an R-multiple', () => {
    expect(averageRMultiple([{ netPnl: 10, rMultiple: null }])).toBeNull();
  });
});

describe('equityCurve / maxDrawdown', () => {
  it('builds a running total', () => {
    expect(equityCurve(trades)).toEqual([100, 50, 250, 150]);
  });
  it('computes max drawdown as a negative number (or 0 if none)', () => {
    // peak hits 250 at trade 3, drawdown to 150 at trade 4 = -100
    expect(maxDrawdown(trades)).toBe(-100);
    expect(maxDrawdown([{ netPnl: 10, rMultiple: null }, { netPnl: 20, rMultiple: null }])).toBe(0);
  });
});
