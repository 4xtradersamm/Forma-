// Pure calculation functions — no side effects, fully unit-testable.
// Contract specs (tick size / tick value) are user-configurable, never assumed.

export interface ContractSpec {
  tickSize: number;   // smallest price increment, e.g. 0.25 for ES
  tickValue: number;  // $ value of one tick per contract
}

export function positionSize(params: {
  accountBalance: number;
  riskPercent: number; // e.g. 1 for 1%
  entryPrice: number;
  stopLossPrice: number;
  contract: ContractSpec;
}): { riskAmount: number; contracts: number; stopDistanceTicks: number } {
  const { accountBalance, riskPercent, entryPrice, stopLossPrice, contract } = params;
  const riskAmount = accountBalance * (riskPercent / 100);
  const stopDistance = Math.abs(entryPrice - stopLossPrice);
  const stopDistanceTicks = stopDistance / contract.tickSize;
  const riskPerContract = stopDistanceTicks * contract.tickValue;
  const contracts = riskPerContract > 0 ? Math.floor(riskAmount / riskPerContract) : 0;
  return { riskAmount, contracts, stopDistanceTicks };
}

export function riskRewardRatio(params: { entryPrice: number; stopLossPrice: number; takeProfitPrice: number }) {
  const { entryPrice, stopLossPrice, takeProfitPrice } = params;
  const risk = Math.abs(entryPrice - stopLossPrice);
  const reward = Math.abs(takeProfitPrice - entryPrice);
  return risk > 0 ? reward / risk : null;
}

export function riskPerTrade(accountBalance: number, riskPercent: number) {
  return accountBalance * (riskPercent / 100);
}

export function percentRisk(riskAmount: number, accountBalance: number) {
  return accountBalance > 0 ? (riskAmount / accountBalance) * 100 : 0;
}

export function dailyLossLimitReached(realizedLossToday: number, accountBalance: number, dailyLossLimitPercent: number) {
  const limit = accountBalance * (dailyLossLimitPercent / 100);
  return { limit, reached: realizedLossToday >= limit, remaining: Math.max(0, limit - realizedLossToday) };
}
