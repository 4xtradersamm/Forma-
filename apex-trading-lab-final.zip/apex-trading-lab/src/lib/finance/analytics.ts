// Journal analytics — computed strictly from recorded trades. No synthetic data.
export interface ClosedTrade { netPnl: number; rMultiple: number | null; }

export function winRate(trades: ClosedTrade[]) {
  if (trades.length === 0) return 0;
  return (trades.filter((t) => t.netPnl > 0).length / trades.length) * 100;
}

export function averageWin(trades: ClosedTrade[]) {
  const wins = trades.filter((t) => t.netPnl > 0);
  return wins.length ? wins.reduce((s, t) => s + t.netPnl, 0) / wins.length : 0;
}

export function averageLoss(trades: ClosedTrade[]) {
  const losses = trades.filter((t) => t.netPnl < 0);
  return losses.length ? losses.reduce((s, t) => s + t.netPnl, 0) / losses.length : 0;
}

export function profitFactor(trades: ClosedTrade[]) {
  const grossProfit = trades.filter((t) => t.netPnl > 0).reduce((s, t) => s + t.netPnl, 0);
  const grossLoss = Math.abs(trades.filter((t) => t.netPnl < 0).reduce((s, t) => s + t.netPnl, 0));
  if (grossLoss === 0) return grossProfit > 0 ? Infinity : 0;
  return grossProfit / grossLoss;
}

export function expectancy(trades: ClosedTrade[]) {
  if (trades.length === 0) return 0;
  const wr = winRate(trades) / 100;
  const avgWin = averageWin(trades);
  const avgLoss = averageLoss(trades);
  return wr * avgWin + (1 - wr) * avgLoss;
}

export function averageRMultiple(trades: ClosedTrade[]) {
  const withR = trades.filter((t): t is ClosedTrade & { rMultiple: number } => t.rMultiple !== null);
  return withR.length ? withR.reduce((s, t) => s + t.rMultiple, 0) / withR.length : null;
}

export function equityCurve(trades: ClosedTrade[]) {
  let running = 0;
  return trades.map((t) => (running += t.netPnl));
}

export function maxDrawdown(trades: ClosedTrade[]) {
  const curve = equityCurve(trades);
  let peak = -Infinity;
  let maxDd = 0;
  for (const point of curve) {
    peak = Math.max(peak, point);
    maxDd = Math.min(maxDd, point - peak);
  }
  return maxDd; // negative number, or 0 if no drawdown
}
