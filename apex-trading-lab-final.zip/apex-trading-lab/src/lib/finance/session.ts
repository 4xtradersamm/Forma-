// Trading-session bucketing by UTC hour. This is a reasonable general convention,
// not a broker- or exchange-specific standard — adjust the boundaries here if your
// markets/sessions differ. Documented explicitly so it's never mistaken for something
// pulled from real session calendars.
export function sessionForDate(date: Date): 'Asian' | 'London' | 'New York' | 'Other' {
  const hour = date.getUTCHours();
  if (hour >= 0 && hour < 7) return 'Asian';
  if (hour >= 7 && hour < 13) return 'London';
  if (hour >= 13 && hour < 21) return 'New York';
  return 'Other';
}
