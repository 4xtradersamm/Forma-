import Link from 'next/link';
import { SignUpForm } from '@/components/auth/sign-up-form';

export default function SignUpPage() {
  return (
    <div className="mx-auto max-w-sm px-6 py-24">
      <h1 className="text-2xl font-semibold text-center">Create your account</h1>
      <p className="text-sm text-muted text-center mt-2">Free to join. Upgrade any time.</p>
      <div className="mt-8">
        <SignUpForm />
      </div>
      <p className="mt-6 text-center text-sm text-muted">
        Already have an account? <Link href="/sign-in" className="text-accent hover:underline">Sign in</Link>
      </p>
    </div>
  );
}
