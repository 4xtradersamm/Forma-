import { PlaybookDetail } from '@/components/models/playbook-detail';
export default function Page({ params }: { params: { id: string } }) {
  return <PlaybookDetail id={params.id} />;
}
