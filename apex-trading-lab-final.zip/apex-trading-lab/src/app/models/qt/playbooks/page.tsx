import { PlaybookList } from '@/components/models/playbook-list';
export default function Page() {
  return <PlaybookList slug="qt" name="QT" />;
}
