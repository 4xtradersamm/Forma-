import { ModelPage } from '@/components/models/model-page';
export default function Page() {
  return <ModelPage name="TTFM" />;
}
