import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { getStripeClient } from '@/lib/payments/stripe';
import { getRazorpayClient } from '@/lib/payments/razorpay';
import { z } from 'zod';

const bodySchema = z.object({ plan_id: z.string().uuid() });

// Creates a checkout session/subscription for whichever provider the selected
// plan is configured for — the client never picks the provider, the plan row does.
export async function POST(request: NextRequest) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: 'Invalid plan.' }, { status: 400 });

  const { data: plan } = await supabase.from('membership_plans').select('*').eq('id', parsed.data.plan_id).eq('is_active', true).maybeSingle();
  if (!plan) return NextResponse.json({ error: 'Plan not found or inactive.' }, { status: 404 });
  if (!plan.provider_price_id) return NextResponse.json({ error: 'This plan has no provider price configured yet. An admin needs to set provider_price_id.' }, { status: 500 });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL!;

  if (plan.provider === 'stripe') {
    const stripe = getStripeClient();
    const { data: existingSub } = await supabase.from('subscriptions').select('provider_customer_id').eq('user_id', user.id).not('provider_customer_id', 'is', null).maybeSingle();

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: existingSub?.provider_customer_id ?? undefined,
      customer_email: existingSub?.provider_customer_id ? undefined : user.email,
      line_items: [{ price: plan.provider_price_id, quantity: 1 }],
      success_url: `${siteUrl}/dashboard/account?checkout=success`,
      cancel_url: `${siteUrl}/pricing?checkout=cancelled`,
      client_reference_id: user.id,
      metadata: { user_id: user.id, plan_id: plan.id },
      subscription_data: { metadata: { user_id: user.id, plan_id: plan.id } },
    });

    return NextResponse.json({ provider: 'stripe', url: session.url });
  }

  if (plan.provider === 'razorpay') {
    const razorpay = getRazorpayClient();
    const subscription = await razorpay.subscriptions.create({
      plan_id: plan.provider_price_id,
      customer_notify: 1,
      total_count: plan.interval === 'annual' ? 1 : 12,
      notes: { user_id: user.id, plan_id: plan.id },
    });

    return NextResponse.json({
      provider: 'razorpay',
      subscriptionId: subscription.id,
      keyId: process.env.RAZORPAY_KEY_ID,
      planName: plan.name,
    });
  }

  return NextResponse.json({ error: `Unsupported provider: ${plan.provider}` }, { status: 500 });
}
