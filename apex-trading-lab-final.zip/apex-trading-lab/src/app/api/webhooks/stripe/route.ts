import { NextResponse, type NextRequest } from 'next/server';
import { getStripeClient } from '@/lib/payments/stripe';
import { createServiceRoleClient } from '@/lib/supabase/server';
import type Stripe from 'stripe';

// Webhook handlers must verify the provider signature before trusting anything in the
// payload, and must be idempotent since providers retry on any non-2xx response.
// This uses the SERVICE ROLE client deliberately: there's no user session here, and
// writing subscription/payment state is exactly the trusted server-side operation
// that key exists for (see the comment on createServiceRoleClient).
export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get('stripe-signature');
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    return NextResponse.json({ error: 'Missing signature or webhook secret.' }, { status: 400 });
  }

  const stripe = getStripeClient();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    return NextResponse.json({ error: `Signature verification failed: ${(err as Error).message}` }, { status: 400 });
  }

  const supabase = createServiceRoleClient();

  // Idempotency: provider_event_id has a unique constraint (0001_init.sql). A duplicate
  // insert means we've already processed this event — acknowledge and stop, don't reapply.
  const { error: insertError } = await supabase.from('payment_events').insert({
    provider: 'stripe',
    provider_event_id: event.id,
    event_type: event.type,
    raw_payload: event as unknown as Record<string, unknown>,
  });
  if (insertError) {
    if (insertError.code === '23505') return NextResponse.json({ received: true, duplicate: true });
    return NextResponse.json({ error: insertError.message }, { status: 500 });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.user_id;
        const planId = session.metadata?.plan_id;
        if (userId && session.subscription) {
          const stripeSubId = typeof session.subscription === 'string' ? session.subscription : session.subscription.id;
          const stripeSub = await stripe.subscriptions.retrieve(stripeSubId);
          await supabase.from('subscriptions').upsert(
            {
              user_id: userId,
              plan_id: planId ?? null,
              status: mapStripeStatus(stripeSub.status),
              provider: 'stripe',
              provider_customer_id: typeof session.customer === 'string' ? session.customer : session.customer?.id,
              provider_subscription_id: stripeSub.id,
              current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString(),
              cancel_at_period_end: stripeSub.cancel_at_period_end,
            },
            { onConflict: 'provider_subscription_id' }
          );
        }
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await supabase
          .from('subscriptions')
          .update({
            status: mapStripeStatus(sub.status),
            current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
            cancel_at_period_end: sub.cancel_at_period_end,
          })
          .eq('provider_subscription_id', sub.id);
        break;
      }
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        if (invoice.subscription) {
          const subId = typeof invoice.subscription === 'string' ? invoice.subscription : invoice.subscription.id;
          await supabase.from('subscriptions').update({ status: 'past_due' }).eq('provider_subscription_id', subId);
        }
        break;
      }
      default:
        break; // ignore event types we don't act on
    }
  } catch (err) {
    return NextResponse.json({ error: `Handler error: ${(err as Error).message}` }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}

function mapStripeStatus(status: Stripe.Subscription.Status): 'active' | 'trialing' | 'past_due' | 'canceled' | 'incomplete' {
  if (status === 'active') return 'active';
  if (status === 'trialing') return 'trialing';
  if (status === 'past_due' || status === 'unpaid') return 'past_due';
  if (status === 'canceled') return 'canceled';
  return 'incomplete';
}
