import { NextResponse, type NextRequest } from 'next/server';
import { verifyRazorpayWebhookSignature } from '@/lib/payments/razorpay';
import { createServiceRoleClient } from '@/lib/supabase/server';

export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get('x-razorpay-signature');

  if (!verifyRazorpayWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Invalid signature.' }, { status: 400 });
  }

  const event = JSON.parse(rawBody);
  const supabase = createServiceRoleClient();

  // Razorpay doesn't send a stable top-level event id in the same place across all
  // event types, so we build one from event type + timestamp + entity id — unique
  // enough to catch a retried delivery of the same event.
  const entityId = event.payload?.subscription?.entity?.id ?? event.payload?.payment?.entity?.id ?? 'unknown';
  const syntheticEventId = `${event.event}:${entityId}:${event.created_at}`;

  const { error: insertError } = await supabase.from('payment_events').insert({
    provider: 'razorpay',
    provider_event_id: syntheticEventId,
    event_type: event.event,
    raw_payload: event,
  });
  if (insertError) {
    if (insertError.code === '23505') return NextResponse.json({ received: true, duplicate: true });
    return NextResponse.json({ error: insertError.message }, { status: 500 });
  }

  try {
    switch (event.event) {
      case 'subscription.activated':
      case 'subscription.charged': {
        const sub = event.payload.subscription.entity;
        const userId = sub.notes?.user_id;
        const planId = sub.notes?.plan_id;
        if (userId) {
          await supabase.from('subscriptions').upsert(
            {
              user_id: userId,
              plan_id: planId ?? null,
              status: 'active',
              provider: 'razorpay',
              provider_subscription_id: sub.id,
              current_period_end: sub.current_end ? new Date(sub.current_end * 1000).toISOString() : null,
              cancel_at_period_end: false,
            },
            { onConflict: 'provider_subscription_id' }
          );
        }
        break;
      }
      case 'subscription.cancelled':
      case 'subscription.completed': {
        const sub = event.payload.subscription.entity;
        await supabase.from('subscriptions').update({ status: 'canceled' }).eq('provider_subscription_id', sub.id);
        break;
      }
      case 'payment.failed': {
        const payment = event.payload.payment.entity;
        if (payment.notes?.user_id) {
          await supabase.from('subscriptions').update({ status: 'past_due' }).eq('user_id', payment.notes.user_id);
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    return NextResponse.json({ error: `Handler error: ${(err as Error).message}` }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
