export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16 prose-invert">
      <h1 className="text-4xl font-semibold">About</h1>
      <div className="mt-8 space-y-4 text-muted leading-relaxed">
        <p>
          [Editable founder biography placeholder — replace via the admin content editor.
          Do not include unverified performance claims, credentials, or testimonials here.]
        </p>
        <h2 className="text-foreground text-xl font-medium mt-8">Mission</h2>
        <p>
          [Editable mission statement placeholder.]
        </p>
      </div>
    </div>
  );
}
