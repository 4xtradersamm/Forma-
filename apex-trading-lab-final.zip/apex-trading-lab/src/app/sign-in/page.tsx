import Link from 'next/link';
import { SignInForm } from '@/components/auth/sign-in-form';

export default function SignInPage() {
  return (
    <div className="mx-auto max-w-sm px-6 py-24">
      <h1 className="text-2xl font-semibold text-center">Sign in</h1>
      <div className="mt-8">
        <SignInForm />
      </div>
      <p className="mt-6 text-center text-sm text-muted">
        Don&apos;t have an account? <Link href="/sign-up" className="text-accent hover:underline">Sign up</Link>
      </p>
    </div>
  );
}
