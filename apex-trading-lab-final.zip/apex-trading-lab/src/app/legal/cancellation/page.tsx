export default function Page() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-4xl font-semibold">Subscription & Cancellation Policy</h1>
      <div className="mt-3 inline-block rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs text-warning">
        Template — requires legal review before publishing
      </div>
      <div className="mt-8 space-y-4 text-muted leading-relaxed whitespace-pre-line">
[Placeholder. Cover: how to cancel, effect of cancellation (access until end of billing period), refund policy (state clearly whether refunds are offered), failed payment handling, and how plan changes are billed. Have a licensed attorney review before publishing.]
      </div>
    </div>
  );
}
