export default function Page() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-4xl font-semibold">Terms of Service</h1>
      <div className="mt-3 inline-block rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs text-warning">
        Template — requires legal review before publishing
      </div>
      <div className="mt-8 space-y-4 text-muted leading-relaxed whitespace-pre-line">
[Placeholder terms of service. Cover: acceptance of terms, account eligibility, acceptable use, intellectual property, disclaimers, limitation of liability, governing law. Have a licensed attorney review before publishing.]
      </div>
    </div>
  );
}
