export default function Page() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-4xl font-semibold">Risk Disclosure</h1>
      <div className="mt-3 inline-block rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs text-warning">
        Template — requires legal review before publishing
      </div>
      <div className="mt-8 space-y-4 text-muted leading-relaxed whitespace-pre-line">
[Placeholder risk disclosure. Must state clearly: trading futures involves substantial risk of loss and is not suitable for all investors; past performance does not guarantee future results; nothing on this platform is financial advice; the QT, GXT, and TTFM models are educational frameworks, not guaranteed strategies. Have a licensed attorney/compliance professional review before publishing.]
      </div>
    </div>
  );
}
