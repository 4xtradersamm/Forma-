export default function Page() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-4xl font-semibold">Privacy Policy</h1>
      <div className="mt-3 inline-block rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs text-warning">
        Template — requires legal review before publishing
      </div>
      <div className="mt-8 space-y-4 text-muted leading-relaxed whitespace-pre-line">
[Placeholder privacy policy. Cover: what data is collected (account, journal entries, uploaded screenshots), how it is stored (Supabase), third parties involved (payment provider, email provider), user rights (access/export/delete), retention, and contact details. Have a licensed attorney review before publishing.]
      </div>
    </div>
  );
}
