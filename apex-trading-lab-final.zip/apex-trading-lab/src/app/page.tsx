import Link from 'next/link';

const MODELS = [
  { slug: 'qt', name: 'QT', blurb: 'Overview, prerequisites, and setup library — full rules published as they are finalized.' },
  { slug: 'gxt', name: 'GXT', blurb: 'Overview, prerequisites, and setup library — full rules published as they are finalized.' },
  { slug: 'ttfm', name: 'TTFM', blurb: 'Overview, prerequisites, and setup library — full rules published as they are finalized.' },
];

const FEATURES = [
  { title: 'Structured playbooks', desc: 'Entry, stop-loss, take-profit, invalidation, and risk rules for every setup, once published.' },
  { title: 'Trading journal', desc: 'Log every trade with screenshots, R-multiples, and rule-adherence tracking.' },
  { title: 'Real analytics', desc: 'Win rate, profit factor, expectancy, and drawdown — computed only from your actual recorded trades.' },
  { title: 'Manual backtesting', desc: 'Research each model against history without pretending to automate a proprietary edge.' },
  { title: 'Calculators', desc: 'Position size, risk/reward, and daily loss-limit tools with configurable contract specs.' },
  { title: 'Live sessions', desc: 'Scheduled sessions and a replay library for paid members.' },
];

const FAQS = [
  { q: 'Are the QT, GXT, and TTFM rules public yet?', a: 'Not all of them. Pages clearly mark placeholder vs. verified content until the founder publishes final rules.' },
  { q: 'Is there a free plan?', a: 'Yes — free members get access to introductory lessons and the calculators. Paid membership unlocks full playbooks, the journal, and live sessions.' },
  { q: 'Do you guarantee trading results?', a: 'No. Nothing on this platform is financial advice, and no performance is guaranteed.' },
];

export default function HomePage() {
  return (
    <div>
      <section className="mx-auto max-w-7xl px-6 pt-24 pb-20 text-center">
        <p className="label-muted mb-4">Trading education &amp; analytics</p>
        <h1 className="text-4xl md:text-6xl font-semibold tracking-tight max-w-3xl mx-auto">
          Learn the models. Track the trades. Trust the numbers.
        </h1>
        <p className="mt-6 text-muted max-w-xl mx-auto">
          A structured home for the QT, GXT, and TTFM trading models — playbooks, lessons,
          a real trading journal, and analytics built from your own recorded results.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <Link href="/sign-up" className="btn-primary">Get started free</Link>
          <Link href="/pricing" className="btn-secondary">View pricing</Link>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <h2 className="text-2xl font-semibold mb-8">The three models</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {MODELS.map((m) => (
            <Link key={m.slug} href={`/models/${m.slug}`} className="card hover:border-accent/50 transition-colors">
              <h3 className="text-xl font-semibold text-accent">{m.name}</h3>
              <p className="mt-2 text-sm text-muted">{m.blurb}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <h2 className="text-2xl font-semibold mb-8">What&apos;s inside</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {FEATURES.map((f) => (
            <div key={f.title} className="card">
              <h3 className="font-medium">{f.title}</h3>
              <p className="mt-2 text-sm text-muted">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <h2 className="text-2xl font-semibold mb-8">Membership</h2>
        <div className="grid md:grid-cols-2 gap-6 max-w-2xl">
          <div className="card">
            <h3 className="font-medium">Free</h3>
            <p className="text-sm text-muted mt-2">Intro lessons, calculators, and community announcements.</p>
          </div>
          <div className="card border-accent/40">
            <h3 className="font-medium text-accent">Paid</h3>
            <p className="text-sm text-muted mt-2">Full playbooks, journal, backtesting, analytics, and live sessions.</p>
          </div>
        </div>
        <Link href="/pricing" className="inline-block mt-6 text-accent text-sm hover:underline">See full plan comparison &rarr;</Link>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 border-t border-border">
        <h2 className="text-2xl font-semibold mb-8">FAQ</h2>
        <div className="space-y-6 max-w-2xl">
          {FAQS.map((f) => (
            <div key={f.q}>
              <h3 className="font-medium">{f.q}</h3>
              <p className="mt-1 text-sm text-muted">{f.a}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
