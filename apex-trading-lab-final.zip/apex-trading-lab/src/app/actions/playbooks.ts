'use server';

import { requireAdmin } from './admin-guard';
import { playbookSchema, toPlaybookRow } from '@/lib/validation/playbook';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export interface ActionState {
  error?: string;
  fieldErrors?: Record<string, string>;
  success?: boolean;
}

function parseForm(formData: FormData) {
  return playbookSchema.safeParse({
    model_id: formData.get('model_id'),
    setup_name: formData.get('setup_name'),
    market_tags: formData.get('market_tags'),
    timeframe_tags: formData.get('timeframe_tags'),
    session_tags: formData.get('session_tags'),
    market_conditions: formData.get('market_conditions'),
    prerequisites: formData.get('prerequisites'),
    entry_conditions: formData.get('entry_conditions'),
    stop_loss_rules: formData.get('stop_loss_rules'),
    take_profit_rules: formData.get('take_profit_rules'),
    invalidation_conditions: formData.get('invalidation_conditions'),
    risk_management_rules: formData.get('risk_management_rules'),
    common_mistakes: formData.get('common_mistakes'),
    is_verified_rule: formData.get('is_verified_rule'),
  });
}

export async function createPlaybookAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const { data, error } = await supabase
    .from('playbooks')
    .insert({ ...toPlaybookRow(parsed.data), status: 'draft' })
    .select('id')
    .single();

  if (error) return { error: error.message };
  revalidatePath('/admin/playbooks');
  redirect(`/admin/playbooks/${data.id}`);
}

export async function updatePlaybookAction(id: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const { error } = await supabase.from('playbooks').update(toPlaybookRow(parsed.data)).eq('id', id);
  if (error) return { error: error.message };

  revalidatePath('/admin/playbooks');
  revalidatePath(`/admin/playbooks/${id}`);
  return { success: true };
}

export async function setPlaybookStatusAction(id: string, status: 'draft' | 'published' | 'archived') {
  const { supabase } = await requireAdmin();
  await supabase.from('playbooks').update({ status }).eq('id', id);
  revalidatePath('/admin/playbooks');
}

export async function deletePlaybookAction(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('playbooks').delete().eq('id', id);
  revalidatePath('/admin/playbooks');
  redirect('/admin/playbooks');
}

export async function reorderPlaybookAction(id: string, sortOrder: number) {
  const { supabase } = await requireAdmin();
  await supabase.from('playbooks').update({ sort_order: sortOrder }).eq('id', id);
  revalidatePath('/admin/playbooks');
}

// Swaps sort_order between two adjacent playbooks within the same model — this is
// what powers the up/down reorder controls in the admin list.
export async function swapPlaybookOrderAction(idA: string, idB: string) {
  const { supabase } = await requireAdmin();
  const { data: rows } = await supabase.from('playbooks').select('id, sort_order').in('id', [idA, idB]);
  if (!rows || rows.length !== 2) return;
  const [a, b] = rows;
  await Promise.all([
    supabase.from('playbooks').update({ sort_order: b.sort_order }).eq('id', a.id),
    supabase.from('playbooks').update({ sort_order: a.sort_order }).eq('id', b.id),
  ]);
  revalidatePath('/admin/playbooks');
}
