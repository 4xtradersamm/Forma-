'use server';

import { createClient } from '@/lib/supabase/server';
import { getStripeClient } from '@/lib/payments/stripe';
import { getRazorpayClient } from '@/lib/payments/razorpay';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';

// Stripe: hand off to Stripe's own hosted billing portal — handles plan changes,
// payment method updates, and cancellation without us reimplementing any of it.
export async function openBillingPortalAction() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/sign-in');

  const { data: sub } = await supabase.from('subscriptions').select('provider, provider_customer_id').eq('user_id', user.id).eq('provider', 'stripe').maybeSingle();
  if (!sub?.provider_customer_id) redirect('/dashboard/account');

  const stripe = getStripeClient();
  const session = await stripe.billingPortal.sessions.create({
    customer: sub.provider_customer_id,
    return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard/account`,
  });
  redirect(session.url);
}

// Razorpay has no hosted portal equivalent — cancel directly via their API.
// The webhook (subscription.cancelled) is still the source of truth for status;
// this just triggers it and gives immediate UI feedback via cancel_at_period_end.
export async function cancelRazorpaySubscriptionAction() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/sign-in');

  const { data: sub } = await supabase.from('subscriptions').select('provider_subscription_id').eq('user_id', user.id).eq('provider', 'razorpay').maybeSingle();
  if (!sub?.provider_subscription_id) return;

  const razorpay = getRazorpayClient();
  await razorpay.subscriptions.cancel(sub.provider_subscription_id, false); // false = cancel at end of cycle, not immediately

  await supabase.from('subscriptions').update({ cancel_at_period_end: true }).eq('provider_subscription_id', sub.provider_subscription_id);
  revalidatePath('/dashboard/account');
}
