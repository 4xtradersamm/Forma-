'use server';

import { requireAdmin } from './admin-guard';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const schema = z.object({
  title: z.string().min(1, 'Title is required').max(120),
  description: z.string().optional(),
  starts_at: z.string().min(1, 'Start time is required'),
  ends_at: z.string().optional(),
  is_paid_only: z.coerce.boolean().optional(),
  join_url: z.string().optional(),
  replay_url: z.string().optional(),
});

export interface ActionState { error?: string; fieldErrors?: Record<string, string>; }

export async function createLiveSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = schema.safeParse({
    title: formData.get('title'),
    description: formData.get('description'),
    starts_at: formData.get('starts_at'),
    ends_at: formData.get('ends_at') || undefined,
    is_paid_only: formData.get('is_paid_only'),
    join_url: formData.get('join_url'),
    replay_url: formData.get('replay_url'),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('live_sessions').insert({
    ...parsed.data,
    starts_at: new Date(parsed.data.starts_at).toISOString(),
    ends_at: parsed.data.ends_at ? new Date(parsed.data.ends_at).toISOString() : null,
    join_url: parsed.data.join_url || null,
    replay_url: parsed.data.replay_url || null,
  });
  if (error) return { error: error.message };
  revalidatePath('/admin/live-sessions');
  revalidatePath('/community');
  return {};
}

export async function deleteLiveSessionAction(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('live_sessions').delete().eq('id', id);
  revalidatePath('/admin/live-sessions');
  revalidatePath('/community');
}
