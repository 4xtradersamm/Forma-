'use server';

import { createClient } from '@/lib/supabase/server';
import { backtestSessionSchema, backtestTradeSchema } from '@/lib/validation/backtest';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export interface ActionState {
  error?: string;
  fieldErrors?: Record<string, string>;
  success?: boolean;
}

export async function createBacktestSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Not signed in.' };

  const parsed = backtestSessionSchema.safeParse({
    model: formData.get('model'),
    instrument: formData.get('instrument'),
    timeframe: formData.get('timeframe'),
    date_range_start: formData.get('date_range_start') || undefined,
    date_range_end: formData.get('date_range_end') || undefined,
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const { data, error } = await supabase
    .from('backtest_sessions')
    .insert({ ...parsed.data, user_id: user.id })
    .select('id')
    .single();

  if (error) return { error: error.message };
  revalidatePath('/dashboard/backtesting');
  redirect(`/dashboard/backtesting/${data.id}`);
}

export async function deleteBacktestSessionAction(id: string) {
  const supabase = createClient();
  await supabase.from('backtest_sessions').delete().eq('id', id);
  revalidatePath('/dashboard/backtesting');
  redirect('/dashboard/backtesting');
}

export async function createBacktestTradeAction(sessionId: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Not signed in.' };

  const parsed = backtestTradeSchema.safeParse({
    setup_date: formData.get('setup_date'),
    entry_price: formData.get('entry_price') || undefined,
    stop_loss_price: formData.get('stop_loss_price') || undefined,
    take_profit_price: formData.get('take_profit_price') || undefined,
    outcome: formData.get('outcome'),
    r_multiple: formData.get('r_multiple') || undefined,
    all_rules_satisfied: formData.get('all_rules_satisfied'),
    chart_image_url: formData.get('chart_image_url') || undefined,
    notes: formData.get('notes'),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const { error } = await supabase.from('backtest_trades').insert({
    ...parsed.data,
    session_id: sessionId,
    user_id: user.id,
    chart_image_url: parsed.data.chart_image_url || null,
    notes: parsed.data.notes || null,
  });

  if (error) return { error: error.message };
  revalidatePath(`/dashboard/backtesting/${sessionId}`);
  return { success: true };
}

export async function deleteBacktestTradeAction(id: string, sessionId: string) {
  const supabase = createClient();
  await supabase.from('backtest_trades').delete().eq('id', id);
  revalidatePath(`/dashboard/backtesting/${sessionId}`);
}
