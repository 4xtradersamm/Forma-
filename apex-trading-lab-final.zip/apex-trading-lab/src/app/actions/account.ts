'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const profileSchema = z.object({
  display_name: z.string().min(1, 'Name is required').max(80),
});

export interface ActionState {
  error?: string;
  fieldErrors?: Record<string, string>;
  success?: boolean;
}

export async function updateProfileAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = profileSchema.safeParse({ display_name: formData.get('display_name') });
  if (!parsed.success) return { fieldErrors: { display_name: parsed.error.issues[0].message } };

  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Not signed in.' };

  // Note: `role` column UPDATE is revoked for authenticated users at the DB grant level
  // (see 0002_rls.sql), so even a tampered request here cannot self-promote to admin.
  const { error } = await supabase.from('profiles').update({ display_name: parsed.data.display_name }).eq('id', user.id);
  if (error) return { error: error.message };

  revalidatePath('/dashboard/account');
  return { success: true };
}
