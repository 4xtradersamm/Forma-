'use server';

import { requireAdmin } from './admin-guard';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';

export interface ActionState { error?: string; fieldErrors?: Record<string, string>; success?: boolean; }

const courseSchema = z.object({
  title: z.string().min(1, 'Title is required').max(120),
  description: z.string().optional(),
  model_id: z.string().uuid().optional().or(z.literal('')),
  is_paid: z.coerce.boolean().optional(),
});

export async function createCourseAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = courseSchema.safeParse({
    title: formData.get('title'), description: formData.get('description'),
    model_id: formData.get('model_id') || undefined, is_paid: formData.get('is_paid'),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { data, error } = await supabase.from('courses').insert({
    title: parsed.data.title, description: parsed.data.description || null,
    model_id: parsed.data.model_id || null, is_paid: parsed.data.is_paid ?? false, status: 'draft',
  }).select('id').single();
  if (error) return { error: error.message };
  revalidatePath('/admin/courses');
  redirect(`/admin/courses/${data.id}`);
}

export async function updateCourseAction(id: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = courseSchema.safeParse({
    title: formData.get('title'), description: formData.get('description'),
    model_id: formData.get('model_id') || undefined, is_paid: formData.get('is_paid'),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('courses').update({
    title: parsed.data.title, description: parsed.data.description || null,
    model_id: parsed.data.model_id || null, is_paid: parsed.data.is_paid ?? false,
  }).eq('id', id);
  if (error) return { error: error.message };
  revalidatePath('/admin/courses');
  revalidatePath(`/admin/courses/${id}`);
  return { success: true };
}

export async function setCourseStatusAction(id: string, status: 'draft' | 'published' | 'archived') {
  const { supabase } = await requireAdmin();
  await supabase.from('courses').update({ status }).eq('id', id);
  revalidatePath('/admin/courses');
  revalidatePath(`/admin/courses/${id}`);
}

export async function deleteCourseAction(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('courses').delete().eq('id', id);
  revalidatePath('/admin/courses');
  redirect('/admin/courses');
}

export async function createModuleAction(courseId: string, formData: FormData) {
  const { supabase } = await requireAdmin();
  const title = formData.get('title') as string;
  if (!title) return;
  await supabase.from('modules').insert({ course_id: courseId, title });
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function deleteModuleAction(id: string, courseId: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('modules').delete().eq('id', id);
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function createLessonAction(moduleId: string, courseId: string, formData: FormData) {
  const { supabase } = await requireAdmin();
  const title = formData.get('title') as string;
  if (!title) return;
  await supabase.from('lessons').insert({ module_id: moduleId, title, status: 'draft' });
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function deleteLessonAction(id: string, courseId: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('lessons').delete().eq('id', id);
  revalidatePath(`/admin/courses/${courseId}`);
}

const lessonSchema = z.object({
  title: z.string().min(1, 'Title is required').max(160),
  body: z.string().optional(),
  video_url: z.string().optional(),
  is_paid: z.coerce.boolean().optional(),
});

export async function updateLessonAction(id: string, courseId: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = lessonSchema.safeParse({
    title: formData.get('title'), body: formData.get('body'),
    video_url: formData.get('video_url'), is_paid: formData.get('is_paid'),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('lessons').update({
    title: parsed.data.title, body: parsed.data.body || null,
    video_url: parsed.data.video_url || null, is_paid: parsed.data.is_paid ?? false,
  }).eq('id', id);
  if (error) return { error: error.message };
  revalidatePath(`/admin/courses/${courseId}`);
  revalidatePath(`/admin/courses/${courseId}/lessons/${id}`);
  return { success: true };
}

export async function setLessonStatusAction(id: string, courseId: string, status: 'draft' | 'published' | 'archived') {
  const { supabase } = await requireAdmin();
  await supabase.from('lessons').update({ status }).eq('id', id);
  revalidatePath(`/admin/courses/${courseId}`);
}
