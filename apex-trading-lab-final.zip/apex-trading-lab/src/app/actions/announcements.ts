'use server';

import { requireAdmin } from './admin-guard';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const schema = z.object({
  title: z.string().min(1, 'Title is required').max(120),
  body: z.string().min(1, 'Body is required').max(2000),
  is_paid_only: z.coerce.boolean().optional(),
});

export interface ActionState { error?: string; fieldErrors?: Record<string, string>; }

export async function createAnnouncementAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = schema.safeParse({ title: formData.get('title'), body: formData.get('body'), is_paid_only: formData.get('is_paid_only') });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('announcements').insert({ ...parsed.data, published_at: new Date().toISOString() });
  if (error) return { error: error.message };
  revalidatePath('/admin/announcements');
  revalidatePath('/community');
  return {};
}

export async function deleteAnnouncementAction(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('announcements').delete().eq('id', id);
  revalidatePath('/admin/announcements');
  revalidatePath('/community');
}
