import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

// Defense in depth: middleware.ts already blocks non-admins from /admin routes,
// and RLS blocks non-admin writes at the database level regardless of this check.
// This just gives server actions a clean, typed way to bail out early with a
// clear redirect instead of relying solely on a Postgres error bubbling up.
export async function requireAdmin() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/sign-in');

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user!.id).single();
  if (profile?.role !== 'admin') redirect('/dashboard');

  return { supabase, userId: user!.id };
}
