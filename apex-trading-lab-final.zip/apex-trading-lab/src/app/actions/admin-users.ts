'use server';

import { requireAdmin } from './admin-guard';
import { createServiceRoleClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';

// Role changes deliberately go through the service-role client: the `role` column has
// UPDATE revoked for the `authenticated` Postgres role at the grant level
// (0002_rls.sql), which blocks self-promotion even by a tampered request from this
// very form. requireAdmin() gates who can reach this action in the first place;
// the service-role client is what makes the actual column write possible for a
// genuine admin.
export async function setUserRoleAction(userId: string, role: 'free' | 'paid' | 'admin') {
  await requireAdmin();
  const supabase = createServiceRoleClient();
  await supabase.from('profiles').update({ role }).eq('id', userId);
  revalidatePath('/admin/users');
}
