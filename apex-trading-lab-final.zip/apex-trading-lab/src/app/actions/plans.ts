'use server';

import { requireAdmin } from './admin-guard';
import { planSchema, toPlanRow } from '@/lib/validation/plan';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export interface ActionState {
  error?: string;
  fieldErrors?: Record<string, string>;
  success?: boolean;
}

function parseForm(formData: FormData) {
  return planSchema.safeParse({
    name: formData.get('name'),
    description: formData.get('description'),
    interval: formData.get('interval'),
    price_cents: formData.get('price_cents'),
    currency: formData.get('currency') || 'USD',
    provider: formData.get('provider'),
    provider_price_id: formData.get('provider_price_id'),
    features: formData.get('features'),
    is_active: formData.get('is_active'),
  });
}

export async function createPlanAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('membership_plans').insert(toPlanRow(parsed.data));
  if (error) return { error: error.message };
  revalidatePath('/admin/plans');
  redirect('/admin/plans');
}

export async function updatePlanAction(id: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }
  const { error } = await supabase.from('membership_plans').update(toPlanRow(parsed.data)).eq('id', id);
  if (error) return { error: error.message };
  revalidatePath('/admin/plans');
  return { success: true };
}

export async function togglePlanActiveAction(id: string, isActive: boolean) {
  const { supabase } = await requireAdmin();
  await supabase.from('membership_plans').update({ is_active: !isActive }).eq('id', id);
  revalidatePath('/admin/plans');
}

export async function deletePlanAction(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from('membership_plans').delete().eq('id', id);
  revalidatePath('/admin/plans');
  redirect('/admin/plans');
}
