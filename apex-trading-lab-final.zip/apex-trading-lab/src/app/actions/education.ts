'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';

export async function markLessonCompleteAction(lessonId: string, courseId: string) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  await supabase
    .from('lesson_progress')
    .upsert(
      { user_id: user.id, lesson_id: lessonId, completed_at: new Date().toISOString(), last_viewed_at: new Date().toISOString() },
      { onConflict: 'user_id,lesson_id' }
    );

  revalidatePath(`/learn/${courseId}`);
  revalidatePath(`/learn/${courseId}/${lessonId}`);
  revalidatePath('/dashboard');
}

export async function toggleBookmarkAction(lessonId: string, courseId: string, isBookmarked: boolean) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  if (isBookmarked) {
    await supabase.from('bookmarks').delete().eq('user_id', user.id).eq('lesson_id', lessonId);
  } else {
    await supabase.from('bookmarks').insert({ user_id: user.id, lesson_id: lessonId });
  }

  revalidatePath(`/learn/${courseId}/${lessonId}`);
  revalidatePath('/dashboard');
}

export async function trackLessonViewAction(lessonId: string) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  await supabase
    .from('lesson_progress')
    .upsert(
      { user_id: user.id, lesson_id: lessonId, last_viewed_at: new Date().toISOString() },
      { onConflict: 'user_id,lesson_id', ignoreDuplicates: false }
    );
}
