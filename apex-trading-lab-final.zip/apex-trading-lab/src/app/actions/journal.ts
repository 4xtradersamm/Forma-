'use server';

import { createClient } from '@/lib/supabase/server';
import { tradeSchema, toTradeRow } from '@/lib/validation/journal';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

export interface ActionState {
  error?: string;
  fieldErrors?: Record<string, string>;
  success?: boolean;
}

function parseForm(formData: FormData) {
  return tradeSchema.safeParse({
    instrument: formData.get('instrument'),
    market: formData.get('market'),
    traded_at: formData.get('traded_at'),
    model: formData.get('model'),
    direction: formData.get('direction'),
    entry_price: formData.get('entry_price') || undefined,
    stop_loss_price: formData.get('stop_loss_price') || undefined,
    take_profit_price: formData.get('take_profit_price') || undefined,
    exit_price: formData.get('exit_price') || undefined,
    position_size: formData.get('position_size') || undefined,
    risk_amount: formData.get('risk_amount') || undefined,
    gross_pnl: formData.get('gross_pnl') || undefined,
    fees: formData.get('fees') || 0,
    r_multiple: formData.get('r_multiple') || undefined,
    setup_followed: formData.get('setup_followed') || undefined,
    emotional_state: formData.get('emotional_state'),
    mistakes: formData.get('mistakes'),
    notes: formData.get('notes'),
    tags: formData.get('tags'),
    is_open: formData.get('is_open'),
    playbook_id: formData.get('playbook_id') || undefined,
  });
}

export async function createTradeAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Not signed in.' };

  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const screenshotBefore = formData.get('screenshot_before_url') as string | null;
  const screenshotAfter = formData.get('screenshot_after_url') as string | null;

  const { data, error } = await supabase
    .from('journal_trades')
    .insert({
      ...toTradeRow(parsed.data),
      user_id: user.id, // also enforced by the RLS `with check` clause — belt and suspenders
      screenshot_before_url: screenshotBefore || null,
      screenshot_after_url: screenshotAfter || null,
    })
    .select('id')
    .single();

  if (error) return { error: error.message };
  revalidatePath('/dashboard/journal');
  redirect(`/dashboard/journal/${data.id}`);
}

export async function updateTradeAction(id: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const supabase = createClient();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
    return { fieldErrors };
  }

  const screenshotBefore = formData.get('screenshot_before_url') as string | null;
  const screenshotAfter = formData.get('screenshot_after_url') as string | null;

  // RLS `journal: owner only` policy means this UPDATE silently affects zero rows if the
  // trade doesn't belong to the caller — no separate ownership check needed here.
  const { error } = await supabase
    .from('journal_trades')
    .update({
      ...toTradeRow(parsed.data),
      screenshot_before_url: screenshotBefore || null,
      screenshot_after_url: screenshotAfter || null,
    })
    .eq('id', id);

  if (error) return { error: error.message };
  revalidatePath('/dashboard/journal');
  revalidatePath(`/dashboard/journal/${id}`);
  return { success: true };
}

export async function deleteTradeAction(id: string) {
  const supabase = createClient();
  await supabase.from('journal_trades').delete().eq('id', id);
  revalidatePath('/dashboard/journal');
  redirect('/dashboard/journal');
}

export async function bulkImportTradesAction(rows: ReturnType<typeof toTradeRow>[]) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Not signed in.', imported: 0 };

  const withOwner = rows.map((r) => ({ ...r, user_id: user.id }));
  const { error, count } = await supabase.from('journal_trades').insert(withOwner, { count: 'exact' });
  if (error) return { error: error.message, imported: 0 };

  revalidatePath('/dashboard/journal');
  return { imported: count ?? rows.length };
}
