import { ResetPasswordForm } from '@/components/auth/reset-password-form';

export default function ResetPasswordPage() {
  return (
    <div className="mx-auto max-w-sm px-6 py-24">
      <h1 className="text-2xl font-semibold text-center">Set a new password</h1>
      <div className="mt-8">
        <ResetPasswordForm />
      </div>
    </div>
  );
}
