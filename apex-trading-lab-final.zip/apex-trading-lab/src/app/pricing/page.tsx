// Plans are fetched from `membership_plans` at request time — never hardcoded here.
import { createClient } from '@/lib/supabase/server';
import { CheckoutButton } from '@/components/pricing/checkout-button';

export default async function PricingPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: plans } = await supabase
    .from('membership_plans')
    .select('*')
    .eq('is_active', true)
    .order('price_cents', { ascending: true });

  const hasPlans = plans && plans.length > 0;

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-4xl font-semibold">Pricing</h1>
      <p className="mt-3 text-muted">Simple membership. Cancel anytime.</p>

      <div className="mt-10 grid md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="font-medium">Free</h2>
          <p className="text-3xl font-semibold mt-2">$0</p>
          <ul className="mt-4 space-y-2 text-sm text-muted">
            <li>Introductory lessons</li>
            <li>Position size &amp; risk calculators</li>
            <li>Public announcements</li>
          </ul>
        </div>

        {hasPlans ? (
          plans!.map((p) => (
            <div key={p.id} className="card border-accent/40">
              <h2 className="font-medium text-accent">{p.name}</h2>
              <p className="text-3xl font-semibold mt-2">
                {(p.price_cents / 100).toLocaleString(undefined, { style: 'currency', currency: p.currency })}
                <span className="text-sm text-muted"> /{p.interval}</span>
              </p>
              <ul className="mt-4 space-y-2 text-sm text-muted">
                {(p.features as string[]).map((f) => <li key={f}>{f}</li>)}
              </ul>
              <CheckoutButton planId={p.id} isSignedIn={!!user} />
            </div>
          ))
        ) : (
          <div className="card border-accent/40">
            <h2 className="font-medium text-accent">Paid membership</h2>
            <p className="mt-2 text-sm text-muted">
              No plans configured yet. Add rows to <code className="text-xs">membership_plans</code> in the admin panel
              to populate monthly/annual pricing here — nothing is hardcoded.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
