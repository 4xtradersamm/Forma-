import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { LiveSessionForm } from '@/components/admin/live-session-form';
import { deleteLiveSessionAction } from '@/app/actions/live-sessions';

export default async function AdminLiveSessionsPage() {
  const supabase = createClient();
  const { data: sessions } = await supabase.from('live_sessions').select('*').order('starts_at', { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">Live sessions</h1>
      <Card className="mb-6"><LiveSessionForm /></Card>
      <div className="space-y-2">
        {(sessions ?? []).map((s) => (
          <Card key={s.id} className="flex items-center justify-between">
            <div>
              <p className="font-medium">{s.title}{s.is_paid_only && <span className="ml-2 text-xs text-accent">Paid only</span>}</p>
              <p className="text-xs text-muted mt-1">{new Date(s.starts_at).toLocaleString()}</p>
            </div>
            <form action={deleteLiveSessionAction.bind(null, s.id)}>
              <button className="text-xs text-muted hover:text-danger">Delete</button>
            </form>
          </Card>
        ))}
      </div>
    </div>
  );
}
