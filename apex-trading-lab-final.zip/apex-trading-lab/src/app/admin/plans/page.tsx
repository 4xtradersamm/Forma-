import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { togglePlanActiveAction } from '@/app/actions/plans';

export default async function AdminPlansPage() {
  const supabase = createClient();
  const { data: plans } = await supabase.from('membership_plans').select('*').order('price_cents');

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Membership plans</h1>
        <Link href="/admin/plans/new" className="btn-primary">New plan</Link>
      </div>
      <div className="mt-6 space-y-3">
        {plans && plans.length > 0 ? (
          plans.map((p) => (
            <Card key={p.id} className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-medium">{p.name}</p>
                  <span className={`text-xs border rounded-full px-2 py-0.5 ${p.is_active ? 'text-accent border-accent/40' : 'text-muted border-border'}`}>
                    {p.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <p className="text-xs text-muted mt-1">
                  {(p.price_cents / 100).toLocaleString(undefined, { style: 'currency', currency: p.currency })}/{p.interval} · {p.provider}
                  {!p.provider_price_id && ' · ⚠ no provider price ID set'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <form action={togglePlanActiveAction.bind(null, p.id, p.is_active)}>
                  <button className="text-xs text-muted hover:underline">{p.is_active ? 'Deactivate' : 'Activate'}</button>
                </form>
                <Link href={`/admin/plans/${p.id}`} className="text-xs text-accent hover:underline">Edit</Link>
              </div>
            </Card>
          ))
        ) : (
          <p className="text-sm text-muted">No plans yet — the pricing page will show a placeholder until you add one.</p>
        )}
      </div>
    </div>
  );
}
