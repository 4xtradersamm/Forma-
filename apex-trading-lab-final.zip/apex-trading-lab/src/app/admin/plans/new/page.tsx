import { PlanForm } from '@/components/admin/plan-form';
import { createPlanAction } from '@/app/actions/plans';

export default function NewPlanPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">New plan</h1>
      <PlanForm action={createPlanAction} submitLabel="Create plan" />
    </div>
  );
}
