import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { PlanForm } from '@/components/admin/plan-form';
import { updatePlanAction, deletePlanAction } from '@/app/actions/plans';
import { Button } from '@/components/ui/button';

export default async function EditPlanPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: plan } = await supabase.from('membership_plans').select('*').eq('id', params.id).single();
  if (!plan) notFound();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Edit plan</h1>
        <form action={deletePlanAction.bind(null, params.id)}>
          <Button type="submit" variant="danger">Delete</Button>
        </form>
      </div>
      <PlanForm defaults={plan} action={updatePlanAction.bind(null, params.id)} submitLabel="Save changes" />
    </div>
  );
}
