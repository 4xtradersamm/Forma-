import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';

export default async function AdminCoursesPage() {
  const supabase = createClient();
  const { data: courses } = await supabase.from('courses').select('*, models(name), modules(id)').order('sort_order');

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Courses</h1>
        <Link href="/admin/courses/new" className="btn-primary">New course</Link>
      </div>
      <div className="mt-6 space-y-2">
        {(courses ?? []).map((c: any) => (
          <Link key={c.id} href={`/admin/courses/${c.id}`}>
            <Card className="flex items-center justify-between hover:border-accent/50 transition-colors">
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-medium">{c.title}</p>
                  <span className={`text-xs border rounded-full px-2 py-0.5 ${c.status === 'published' ? 'text-accent border-accent/40' : 'text-muted border-border'}`}>{c.status}</span>
                </div>
                <p className="text-xs text-muted mt-1">{c.models?.name ?? 'General'} · {c.modules?.length ?? 0} module(s){c.is_paid && ' · Paid'}</p>
              </div>
            </Card>
          </Link>
        ))}
        {(!courses || courses.length === 0) && <p className="text-sm text-muted">No courses yet.</p>}
      </div>
    </div>
  );
}
