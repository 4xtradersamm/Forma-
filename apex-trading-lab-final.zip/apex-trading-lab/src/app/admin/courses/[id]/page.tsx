import { notFound } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { CourseForm } from '@/components/admin/course-form';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  updateCourseAction, deleteCourseAction, setCourseStatusAction,
  createModuleAction, deleteModuleAction, createLessonAction, deleteLessonAction, setLessonStatusAction,
} from '@/app/actions/courses';

export default async function EditCoursePage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const [{ data: models }, { data: course }, { data: modules }] = await Promise.all([
    supabase.from('models').select('id, name').order('slug'),
    supabase.from('courses').select('*').eq('id', params.id).single(),
    supabase.from('modules').select('*, lessons(id, title, status, sort_order)').eq('course_id', params.id).order('sort_order'),
  ]);
  if (!course) notFound();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">{course.title}</h1>
        <div className="flex items-center gap-2">
          {course.status !== 'published' ? (
            <form action={setCourseStatusAction.bind(null, params.id, 'published')}><button className="btn-secondary text-sm px-3 py-1.5">Publish</button></form>
          ) : (
            <form action={setCourseStatusAction.bind(null, params.id, 'draft')}><button className="btn-secondary text-sm px-3 py-1.5">Unpublish</button></form>
          )}
          <form action={deleteCourseAction.bind(null, params.id)}><Button type="submit" variant="danger">Delete course</Button></form>
        </div>
      </div>

      <Card className="mb-6">
        <h2 className="font-medium mb-4">Course details</h2>
        <CourseForm models={models ?? []} defaults={course} action={updateCourseAction.bind(null, params.id)} submitLabel="Save changes" />
      </Card>

      <h2 className="font-medium mb-3">Modules &amp; lessons</h2>
      <div className="space-y-4">
        {(modules ?? []).map((m: any) => (
          <Card key={m.id}>
            <div className="flex items-center justify-between mb-3">
              <p className="font-medium">{m.title}</p>
              <form action={deleteModuleAction.bind(null, m.id, params.id)}><button className="text-xs text-muted hover:text-danger">Delete module</button></form>
            </div>
            <div className="space-y-2">
              {(m.lessons ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order).map((l: any) => (
                <div key={l.id} className="flex items-center justify-between border-t border-border pt-2">
                  <div className="flex items-center gap-2 text-sm">
                    <span>{l.title}</span>
                    <span className={`text-xs border rounded-full px-2 py-0.5 ${l.status === 'published' ? 'text-accent border-accent/40' : 'text-muted border-border'}`}>{l.status}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {l.status !== 'published' ? (
                      <form action={setLessonStatusAction.bind(null, l.id, params.id, 'published')}><button className="text-xs text-accent hover:underline">Publish</button></form>
                    ) : (
                      <form action={setLessonStatusAction.bind(null, l.id, params.id, 'draft')}><button className="text-xs text-muted hover:underline">Unpublish</button></form>
                    )}
                    <Link href={`/admin/courses/${params.id}/lessons/${l.id}`} className="text-xs text-accent hover:underline">Edit</Link>
                    <form action={deleteLessonAction.bind(null, l.id, params.id)}><button className="text-xs text-muted hover:text-danger">Delete</button></form>
                  </div>
                </div>
              ))}
            </div>
            <form action={createLessonAction.bind(null, m.id, params.id)} className="flex gap-2 mt-3 pt-3 border-t border-border">
              <input name="title" placeholder="New lesson title" className="flex-1 rounded-lg border border-border bg-surface px-3 py-1.5 text-sm" required />
              <button type="submit" className="text-xs text-accent hover:underline">Add lesson</button>
            </form>
          </Card>
        ))}

        <Card>
          <form action={createModuleAction.bind(null, params.id)} className="flex gap-2">
            <input name="title" placeholder="New module title" className="flex-1 rounded-lg border border-border bg-surface px-3 py-1.5 text-sm" required />
            <button type="submit" className="btn-secondary text-sm px-3 py-1.5">Add module</button>
          </form>
        </Card>
      </div>
    </div>
  );
}
