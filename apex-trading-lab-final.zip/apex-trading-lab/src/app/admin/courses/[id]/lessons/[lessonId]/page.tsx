import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { LessonForm } from '@/components/admin/lesson-form';
import { updateLessonAction } from '@/app/actions/courses';

export default async function EditLessonPage({ params }: { params: { id: string; lessonId: string } }) {
  const supabase = createClient();
  const { data: lesson } = await supabase.from('lessons').select('*').eq('id', params.lessonId).single();
  if (!lesson) notFound();

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">Edit lesson</h1>
      <LessonForm defaults={lesson} action={updateLessonAction.bind(null, params.lessonId, params.id)} />
    </div>
  );
}
