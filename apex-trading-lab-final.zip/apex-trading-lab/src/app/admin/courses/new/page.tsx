import { createClient } from '@/lib/supabase/server';
import { CourseForm } from '@/components/admin/course-form';
import { createCourseAction } from '@/app/actions/courses';

export default async function NewCoursePage() {
  const supabase = createClient();
  const { data: models } = await supabase.from('models').select('id, name').order('slug');
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">New course</h1>
      <CourseForm models={models ?? []} action={createCourseAction} submitLabel="Create course" />
    </div>
  );
}
