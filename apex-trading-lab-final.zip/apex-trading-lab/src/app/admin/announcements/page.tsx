import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { AnnouncementForm } from '@/components/admin/announcement-form';
import { deleteAnnouncementAction } from '@/app/actions/announcements';

export default async function AdminAnnouncementsPage() {
  const supabase = createClient();
  const { data: announcements } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">Announcements</h1>
      <Card className="mb-6"><AnnouncementForm /></Card>
      <div className="space-y-2">
        {(announcements ?? []).map((a) => (
          <Card key={a.id} className="flex items-center justify-between">
            <div>
              <p className="font-medium">{a.title}{a.is_paid_only && <span className="ml-2 text-xs text-accent">Paid only</span>}</p>
              <p className="text-sm text-muted mt-1">{a.body}</p>
            </div>
            <form action={deleteAnnouncementAction.bind(null, a.id)}>
              <button className="text-xs text-muted hover:text-danger">Delete</button>
            </form>
          </Card>
        ))}
      </div>
    </div>
  );
}
