import { requireAdmin } from '@/app/actions/admin-guard';
import { createServiceRoleClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { setUserRoleAction } from '@/app/actions/admin-users';

const ROLES = ['free', 'paid', 'admin'] as const;

export default async function AdminUsersPage() {
  const { supabase } = await requireAdmin();

  const { data: profiles } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });

  // Email lives on auth.users, not profiles — only reachable via the Admin API,
  // which requires the service-role key (never exposed to the browser).
  const service = createServiceRoleClient();
  const { data: authUsers } = await service.auth.admin.listUsers();
  const emailById = new Map((authUsers?.users ?? []).map((u) => [u.id, u.email]));

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">Users</h1>
      <div className="space-y-2">
        {(profiles ?? []).map((p) => (
          <Card key={p.id} className="flex items-center justify-between py-3">
            <div>
              <p className="font-medium">{p.display_name || emailById.get(p.id) || p.id}</p>
              <p className="text-xs text-muted">{emailById.get(p.id)}</p>
            </div>
            <form action={async (formData: FormData) => {
              'use server';
              await setUserRoleAction(p.id, formData.get('role') as 'free' | 'paid' | 'admin');
            }} className="flex items-center gap-2">
              <select name="role" defaultValue={p.role} className="rounded-lg border border-border bg-surface px-3 py-1.5 text-sm">
                {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
              <button type="submit" className="text-xs text-accent hover:underline">Update</button>
            </form>
          </Card>
        ))}
      </div>
    </div>
  );
}
