import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { PlaybookForm } from '@/components/admin/playbook-form';
import { updatePlaybookAction, deletePlaybookAction } from '@/app/actions/playbooks';
import { Button } from '@/components/ui/button';

export default async function EditPlaybookPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const [{ data: models }, { data: playbook }] = await Promise.all([
    supabase.from('models').select('id, slug, name').order('slug'),
    supabase.from('playbooks').select('*').eq('id', params.id).single(),
  ]);

  if (!playbook) notFound();

  const boundUpdate = updatePlaybookAction.bind(null, params.id);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Edit playbook</h1>
        <form action={deletePlaybookAction.bind(null, params.id)}>
          <Button type="submit" variant="danger">Delete</Button>
        </form>
      </div>
      <PlaybookForm models={models ?? []} defaults={playbook} action={boundUpdate} submitLabel="Save changes" />
    </div>
  );
}
