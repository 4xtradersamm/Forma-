import { createClient } from '@/lib/supabase/server';
import { PlaybookForm } from '@/components/admin/playbook-form';
import { createPlaybookAction } from '@/app/actions/playbooks';

export default async function NewPlaybookPage() {
  const supabase = createClient();
  const { data: models } = await supabase.from('models').select('id, slug, name').order('slug');

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">New playbook</h1>
      <PlaybookForm models={models ?? []} action={createPlaybookAction} submitLabel="Create playbook" />
    </div>
  );
}
