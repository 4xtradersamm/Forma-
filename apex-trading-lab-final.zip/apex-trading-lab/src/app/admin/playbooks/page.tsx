import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { setPlaybookStatusAction, swapPlaybookOrderAction } from '@/app/actions/playbooks';

const STATUS_COLORS: Record<string, string> = {
  draft: 'text-muted border-border',
  published: 'text-accent border-accent/40',
  archived: 'text-muted border-border line-through',
};

export default async function AdminPlaybooksPage() {
  const supabase = createClient();
  const { data: models } = await supabase.from('models').select('id, slug, name').order('slug');
  const { data: playbooks } = await supabase
    .from('playbooks')
    .select('*, models(slug, name)')
    .order('model_id')
    .order('sort_order');

  // Group by model so up/down reorder only ever swaps within the same model's list —
  // reordering QT setups should never touch GXT's order.
  const grouped = new Map<string, any[]>();
  for (const p of playbooks ?? []) {
    const key = p.models?.slug ?? 'unknown';
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key)!.push(p);
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Playbooks</h1>
        <Link href="/admin/playbooks/new" className="btn-primary">New playbook</Link>
      </div>

      {(!models || models.length === 0) && (
        <Card className="mt-6 border-warning/40">
          <p className="text-sm text-warning">
            No rows exist in the <code>models</code> table yet. Insert QT/GXT/TTFM rows there first
            (slug must be exactly &quot;qt&quot;, &quot;gxt&quot;, or &quot;ttfm&quot;) — the new-playbook
            form needs at least one model to attach to.
          </p>
        </Card>
      )}

      <div className="mt-6 space-y-8">
        {Array.from(grouped.entries()).map(([slug, items]) => (
          <div key={slug}>
            <p className="label-muted mb-2">{slug}</p>
            <div className="space-y-3">
              {items.map((p, i) => (
                <Card key={p.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col">
                      <form action={swapPlaybookOrderAction.bind(null, p.id, i > 0 ? items[i - 1].id : p.id)}>
                        <button type="submit" disabled={i === 0} className="text-xs text-muted hover:text-accent disabled:opacity-20 disabled:cursor-not-allowed">▲</button>
                      </form>
                      <form action={swapPlaybookOrderAction.bind(null, p.id, i < items.length - 1 ? items[i + 1].id : p.id)}>
                        <button type="submit" disabled={i === items.length - 1} className="text-xs text-muted hover:text-accent disabled:opacity-20 disabled:cursor-not-allowed">▼</button>
                      </form>
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs border rounded-full px-2 py-0.5 ${STATUS_COLORS[p.status]}`}>{p.status}</span>
                        {!p.is_verified_rule && (
                          <span className="text-xs border border-warning/40 text-warning rounded-full px-2 py-0.5">placeholder</span>
                        )}
                      </div>
                      <p className="font-medium mt-1">{p.setup_name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {p.status !== 'published' ? (
                      <form action={setPlaybookStatusAction.bind(null, p.id, 'published')}>
                        <button className="text-xs text-accent hover:underline">Publish</button>
                      </form>
                    ) : (
                      <form action={setPlaybookStatusAction.bind(null, p.id, 'draft')}>
                        <button className="text-xs text-muted hover:underline">Unpublish</button>
                      </form>
                    )}
                    {p.status !== 'archived' && (
                      <form action={setPlaybookStatusAction.bind(null, p.id, 'archived')}>
                        <button className="text-xs text-muted hover:underline">Archive</button>
                      </form>
                    )}
                    <Link href={`/admin/playbooks/${p.id}`} className="text-xs text-accent hover:underline">Edit</Link>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))}
        {(!playbooks || playbooks.length === 0) && <p className="text-sm text-muted">No playbooks yet.</p>}
      </div>
    </div>
  );
}
