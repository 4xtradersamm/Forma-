import Link from 'next/link';

const NAV = [
  { href: '/admin', label: 'Overview' },
  { href: '/admin/playbooks', label: 'Playbooks' },
  { href: '/admin/courses', label: 'Courses & lessons' },
  { href: '/admin/users', label: 'Users' },
  { href: '/admin/plans', label: 'Membership plans' },
  { href: '/admin/announcements', label: 'Announcements' },
  { href: '/admin/live-sessions', label: 'Live sessions' },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12 grid md:grid-cols-[220px_1fr] gap-10">
      <aside>
        <p className="label-muted mb-3">Admin</p>
        <nav className="space-y-1">
          {NAV.map((item) =>
            item.disabled ? (
              <span key={item.href} className="block px-3 py-2 text-sm text-muted/50 cursor-not-allowed">
                {item.label}
              </span>
            ) : (
              <Link key={item.href} href={item.href} className="block px-3 py-2 text-sm rounded-lg hover:bg-surface-hover transition-colors">
                {item.label}
              </Link>
            )
          )}
        </nav>
      </aside>
      <div>{children}</div>
    </div>
  );
}
