import { createClient } from '@/lib/supabase/server';
import { Card, StatCard } from '@/components/ui/card';

export default async function AdminOverviewPage() {
  const supabase = createClient();

  const [{ count: userCount }, { count: paidCount }, { count: playbookCount }, { count: tradeCount }] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('subscriptions').select('*', { count: 'exact', head: true }).in('status', ['active', 'trialing']),
    supabase.from('playbooks').select('*', { count: 'exact', head: true }),
    supabase.from('journal_trades').select('*', { count: 'exact', head: true }),
  ]);

  return (
    <div>
      <h1 className="text-2xl font-semibold">Admin overview</h1>
      <div className="grid md:grid-cols-4 gap-4 mt-8">
        <StatCard label="Total users" value={String(userCount ?? 0)} />
        <StatCard label="Active paid members" value={String(paidCount ?? 0)} />
        <StatCard label="Playbooks (all statuses)" value={String(playbookCount ?? 0)} />
        <StatCard label="Journal trades logged" value={String(tradeCount ?? 0)} hint="Across all users" />
      </div>
      <Card className="mt-8">
        <h2 className="font-medium">Next steps</h2>
        <p className="text-sm text-muted mt-2">
          Manage playbooks, courses/lessons, users, membership plans, announcements, and
          live sessions from the sidebar. Everything here writes through the same RLS
          policies as the public site — an admin session is what unlocks the writes, not
          a separate trust boundary.
        </p>
      </Card>
    </div>
  );
}
