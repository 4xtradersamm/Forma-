import { NewSessionForm } from '@/components/backtest/new-session-form';

export default function NewBacktestSessionPage() {
  return (
    <div className="mx-auto max-w-xl px-6 py-12">
      <h1 className="text-2xl font-semibold mb-6">New backtesting session</h1>
      <NewSessionForm />
    </div>
  );
}
