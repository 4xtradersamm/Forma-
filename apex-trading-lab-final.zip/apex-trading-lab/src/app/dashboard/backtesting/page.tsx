import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { winRate, profitFactor, expectancy } from '@/lib/finance/analytics';

export default async function BacktestingPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: sessions } = await supabase
    .from('backtest_sessions')
    .select('*, backtest_trades(outcome, r_multiple, all_rules_satisfied)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  // Compare results between models: aggregate every backtest trade across all of this
  // user's sessions, grouped by model. R-multiple stands in for "net P&L" here since
  // backtest trades are hypothetical — there's no real currency P&L to sum.
  const byModel: Record<string, { netPnl: number; rMultiple: number | null }[]> = { QT: [], GXT: [], TTFM: [], OTHER: [] };
  for (const s of sessions ?? []) {
    for (const t of (s as any).backtest_trades ?? []) {
      if (t.r_multiple === null) continue;
      byModel[s.model]?.push({ netPnl: Number(t.r_multiple), rMultiple: Number(t.r_multiple) });
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Backtesting</h1>
        <Link href="/dashboard/backtesting/new" className="btn-primary">New session</Link>
      </div>
      <p className="text-sm text-muted mt-1">
        Manual research journal — this records hypothetical setups you identify by hand.
        It does not claim to automate or reproduce your models.
      </p>

      <Card className="mt-6">
        <h2 className="font-medium mb-4">Compare models (R-multiple based)</h2>
        <div className="grid grid-cols-3 gap-4 text-sm">
          {(['QT', 'GXT', 'TTFM'] as const).map((m) => {
            const trades = byModel[m];
            return (
              <div key={m} className="text-center">
                <p className="font-medium">{m}</p>
                {trades.length > 0 ? (
                  <>
                    <p className="text-muted text-xs mt-1">{trades.length} trades</p>
                    <p className="font-mono mt-1">{winRate(trades).toFixed(0)}% win</p>
                    <p className="font-mono text-xs text-muted">PF {profitFactor(trades) === Infinity ? '∞' : profitFactor(trades).toFixed(2)} · Exp {expectancy(trades).toFixed(2)}R</p>
                  </>
                ) : (
                  <p className="text-muted text-xs mt-1">No data</p>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      <div className="mt-6 space-y-3">
        {sessions && sessions.length > 0 ? (
          sessions.map((s: any) => (
            <Link key={s.id} href={`/dashboard/backtesting/${s.id}`}>
              <Card className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{s.instrument} · {s.timeframe}</p>
                  <p className="text-xs text-muted mt-1">{s.model} · {s.backtest_trades?.length ?? 0} recorded setups</p>
                </div>
                <span className="text-xs text-muted">{new Date(s.created_at).toLocaleDateString()}</span>
              </Card>
            </Link>
          ))
        ) : (
          <p className="text-sm text-muted">No backtesting sessions yet.</p>
        )}
      </div>
    </div>
  );
}
