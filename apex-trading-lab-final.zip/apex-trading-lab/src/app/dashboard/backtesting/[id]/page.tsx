import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AddTradeForm } from '@/components/backtest/add-trade-form';
import { BacktestCsvExportButton } from '@/components/backtest/csv-export-button';
import { deleteBacktestSessionAction, deleteBacktestTradeAction } from '@/app/actions/backtest';
import { winRate, profitFactor, expectancy, averageRMultiple } from '@/lib/finance/analytics';

const OUTCOME_COLOR: Record<string, string> = {
  win: 'text-accent', loss: 'text-danger', breakeven: 'text-muted', invalid: 'text-warning',
};

export default async function BacktestSessionPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: session } = await supabase.from('backtest_sessions').select('*').eq('id', params.id).maybeSingle();
  if (!session) notFound();

  const { data: trades } = await supabase
    .from('backtest_trades')
    .select('*')
    .eq('session_id', params.id)
    .order('setup_date', { ascending: false });

  // R-multiple stands in for "net P&L" in these formulas — appropriate here since
  // backtest trades are hypothetical, not real executed P&L.
  const forCalc = (trades ?? [])
    .filter((t) => t.r_multiple !== null)
    .map((t) => ({ netPnl: Number(t.r_multiple), rMultiple: Number(t.r_multiple) }));

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">{session.instrument} · {session.timeframe}</h1>
          <p className="text-sm text-muted mt-1">{session.model} model</p>
        </div>
        <form action={deleteBacktestSessionAction.bind(null, params.id)}>
          <Button type="submit" variant="danger">Delete session</Button>
        </form>
      </div>

      <div className="mt-4">
        <BacktestCsvExportButton sessionId={params.id} />
      </div>

      {forCalc.length > 0 && (
        <Card className="mt-6">
          <div className="grid grid-cols-4 gap-4 text-center text-sm">
            <div><p className="font-mono text-lg">{winRate(forCalc).toFixed(0)}%</p><p className="text-muted text-xs mt-1">Win rate</p></div>
            <div><p className="font-mono text-lg">{profitFactor(forCalc) === Infinity ? '∞' : profitFactor(forCalc).toFixed(2)}</p><p className="text-muted text-xs mt-1">Profit factor</p></div>
            <div><p className="font-mono text-lg">{expectancy(forCalc).toFixed(2)}R</p><p className="text-muted text-xs mt-1">Expectancy</p></div>
            <div><p className="font-mono text-lg">{averageRMultiple(forCalc)?.toFixed(2) ?? '—'}</p><p className="text-muted text-xs mt-1">Avg R-multiple</p></div>
          </div>
        </Card>
      )}

      <Card className="mt-6">
        <h2 className="font-medium mb-4">Add a hypothetical setup</h2>
        <AddTradeForm sessionId={params.id} userId={user.id} />
      </Card>

      <div className="mt-6 space-y-2">
        {trades && trades.length > 0 ? (
          trades.map((t) => (
            <Card key={t.id} className="flex items-center justify-between py-3">
              <div className="flex items-center gap-4 text-sm">
                <span className="text-muted font-mono">{new Date(t.setup_date).toLocaleDateString()}</span>
                <span className={`font-medium ${OUTCOME_COLOR[t.outcome ?? '']}`}>{t.outcome}</span>
                {t.r_multiple !== null && <span className="font-mono text-xs">{Number(t.r_multiple).toFixed(2)}R</span>}
                {t.all_rules_satisfied && <span className="text-xs text-accent">All rules ✓</span>}
              </div>
              <form action={deleteBacktestTradeAction.bind(null, t.id, params.id)}>
                <button className="text-xs text-muted hover:text-danger">Remove</button>
              </form>
            </Card>
          ))
        ) : (
          <p className="text-sm text-muted">No setups recorded yet.</p>
        )}
      </div>
    </div>
  );
}
