import { PositionSizeCalculator } from '@/components/calculators/position-size-calculator';
import { RiskRewardCalculator } from '@/components/calculators/risk-reward-calculator';
import { RiskPerTradeCalculator } from '@/components/calculators/risk-per-trade-calculator';
import { PercentRiskCalculator } from '@/components/calculators/percent-risk-calculator';
import { DailyLossLimitCalculator } from '@/components/calculators/daily-loss-limit-calculator';

export default function CalculatorsPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-12 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Calculators</h1>
        <p className="text-sm text-muted mt-1">
          All figures are illustrative — verify contract specifications and broker-specific
          details before sizing a real position.
        </p>
      </div>
      <PositionSizeCalculator />
      <RiskRewardCalculator />
      <RiskPerTradeCalculator />
      <PercentRiskCalculator />
      <DailyLossLimitCalculator />
    </div>
  );
}
