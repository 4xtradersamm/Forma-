import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card, StatCard } from '@/components/ui/card';

// Dashboard is a Server Component: every query below runs under the signed-in
// user's session, so RLS naturally restricts each result to their own data.
export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null; // middleware already redirects unauthenticated users

  const [{ data: profile }, { data: subscription }, { data: recentTrades }, { data: savedLessons }, { data: recentLessons }, { data: announcements }] =
    await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).single(),
      supabase.from('subscriptions').select('*, membership_plans(name)').eq('user_id', user.id).in('status', ['active', 'trialing']).maybeSingle(),
      supabase.from('journal_trades').select('*').eq('user_id', user.id).order('traded_at', { ascending: false }).limit(5),
      supabase.from('bookmarks').select('*, lessons(title, id)').eq('user_id', user.id).limit(5),
      supabase.from('lesson_progress').select('*, lessons(title, id)').eq('user_id', user.id).order('last_viewed_at', { ascending: false }).limit(5),
      supabase.from('announcements').select('*').not('published_at', 'is', null).order('published_at', { ascending: false }).limit(3),
    ]);

  const isPaid = !!subscription;
  const closedTrades = (recentTrades ?? []).filter((t) => !t.is_open);
  const netPnl = closedTrades.reduce((sum, t) => sum + Number(t.net_pnl ?? 0), 0);

  const modelProgress: Record<string, number> = { QT: 0, GXT: 0, TTFM: 0 };
  // Placeholder progress calc — replace with a real join against course/lesson counts per model
  // once the education system UI (Phase 4) links lessons to models directly.

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Welcome back{profile?.display_name ? `, ${profile.display_name}` : ''}</h1>
          <p className="text-sm text-muted mt-1">
            {isPaid ? `Paid member — ${subscription?.membership_plans?.name ?? 'active plan'}` : 'Free member'}
          </p>
        </div>
        {!isPaid && <Link href="/pricing" className="btn-primary">Upgrade</Link>}
      </div>

      <div className="grid md:grid-cols-4 gap-4 mt-8">
        <StatCard label="Net P&L (last 5 trades)" value={netPnl.toLocaleString(undefined, { style: 'currency', currency: 'USD' })} />
        <StatCard label="QT progress" value={`${modelProgress.QT}%`} />
        <StatCard label="GXT progress" value={`${modelProgress.GXT}%`} />
        <StatCard label="TTFM progress" value={`${modelProgress.TTFM}%`} />
      </div>

      <div className="grid md:grid-cols-2 gap-6 mt-8">
        <Card>
          <div className="flex items-center justify-between">
            <h2 className="font-medium">Recent journal entries</h2>
            <Link href="/dashboard/journal" className="text-xs text-accent hover:underline">View all</Link>
          </div>
          <div className="mt-4 space-y-3">
            {recentTrades && recentTrades.length > 0 ? (
              recentTrades.map((t) => (
                <div key={t.id} className="flex justify-between text-sm border-b border-border pb-2 last:border-0">
                  <span>{t.instrument} · {t.model}</span>
                  <span className={Number(t.net_pnl) >= 0 ? 'text-accent' : 'text-danger'}>
                    {Number(t.net_pnl ?? 0).toLocaleString(undefined, { style: 'currency', currency: 'USD' })}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted">No trades logged yet.</p>
            )}
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <h2 className="font-medium">Continue learning</h2>
            <Link href="/models/qt" className="text-xs text-accent hover:underline">Browse models</Link>
          </div>
          <div className="mt-4 space-y-3">
            {recentLessons && recentLessons.length > 0 ? (
              recentLessons.map((lp: any) => (
                <div key={lp.lesson_id} className="text-sm border-b border-border pb-2 last:border-0">
                  {lp.lessons?.title ?? 'Untitled lesson'}
                </div>
              ))
            ) : (
              <p className="text-sm text-muted">No lessons viewed yet.</p>
            )}
          </div>
        </Card>

        <Card>
          <h2 className="font-medium">Saved lessons</h2>
          <div className="mt-4 space-y-3">
            {savedLessons && savedLessons.length > 0 ? (
              savedLessons.map((b: any) => (
                <div key={b.lesson_id} className="text-sm border-b border-border pb-2 last:border-0">
                  {b.lessons?.title ?? 'Untitled lesson'}
                </div>
              ))
            ) : (
              <p className="text-sm text-muted">Nothing bookmarked yet.</p>
            )}
          </div>
        </Card>

        <Card>
          <h2 className="font-medium">Announcements</h2>
          <div className="mt-4 space-y-3">
            {announcements && announcements.length > 0 ? (
              announcements.map((a) => (
                <div key={a.id} className="text-sm border-b border-border pb-2 last:border-0">
                  <p className="font-medium">{a.title}</p>
                  <p className="text-muted text-xs mt-0.5">{a.body}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted">No announcements yet.</p>
            )}
          </div>
        </Card>
      </div>

      <div className="mt-8 flex flex-wrap gap-3">
        <Link href="/dashboard/calculators" className="btn-secondary">Calculators</Link>
        <Link href="/dashboard/journal" className="btn-secondary">Trading journal</Link>
        <Link href="/dashboard/analytics" className="btn-secondary">Analytics</Link>
        <Link href="/dashboard/backtesting" className="btn-secondary">Backtesting</Link>
        <Link href="/dashboard/account" className="btn-secondary">Account settings</Link>
      </div>
    </div>
  );
}
