import { createClient } from '@/lib/supabase/server';
import { StatCard } from '@/components/ui/card';
import { Card } from '@/components/ui/card';
import { EquityCurveChart } from '@/components/analytics/equity-curve-chart';
import { BreakdownBarChart } from '@/components/analytics/breakdown-bar-chart';
import {
  winRate, averageWin, averageLoss, profitFactor, expectancy, averageRMultiple, maxDrawdown,
} from '@/lib/finance/analytics';
import { sessionForDate } from '@/lib/finance/session';

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const fmt = (n: number) => n.toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

function groupSum<T>(items: T[], keyFn: (t: T) => string, valueFn: (t: T) => number) {
  const map = new Map<string, number>();
  for (const item of items) {
    const key = keyFn(item);
    map.set(key, (map.get(key) ?? 0) + valueFn(item));
  }
  return Array.from(map.entries()).map(([label, value]) => ({ label, value }));
}

export default async function AnalyticsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  // Only closed trades count toward performance stats — an open trade has no realized
  // P&L yet, so including it would silently distort every ratio below.
  const { data: allTrades } = await supabase
    .from('journal_trades')
    .select('*, playbooks(setup_name)')
    .eq('user_id', user.id)
    .order('traded_at', { ascending: true });

  const openCount = (allTrades ?? []).filter((t) => t.is_open).length;
  const closed = (allTrades ?? []).filter((t) => !t.is_open);
  const closedForCalc = closed.map((t) => ({ netPnl: Number(t.net_pnl ?? 0), rMultiple: t.r_multiple !== null ? Number(t.r_multiple) : null }));

  const netPnl = closedForCalc.reduce((s, t) => s + t.netPnl, 0);
  const wr = winRate(closedForCalc);
  const avgWin = averageWin(closedForCalc);
  const avgLoss = averageLoss(closedForCalc);
  const pf = profitFactor(closedForCalc);
  const exp = expectancy(closedForCalc);
  const avgR = averageRMultiple(closedForCalc);
  const dd = maxDrawdown(closedForCalc);

  let running = 0;
  const equityCurveData = closed.map((t, i) => {
    running += Number(t.net_pnl ?? 0);
    return { trade: i + 1, equity: running };
  });

  const byModel = groupSum(closed, (t) => t.model, (t) => Number(t.net_pnl ?? 0));
  const byInstrument = groupSum(closed, (t) => t.instrument, (t) => Number(t.net_pnl ?? 0));
  const byDayOfWeek = groupSum(closed, (t) => DAY_NAMES[new Date(t.traded_at).getDay()], (t) => Number(t.net_pnl ?? 0))
    .sort((a, b) => DAY_NAMES.indexOf(a.label) - DAY_NAMES.indexOf(b.label));
  const bySession = groupSum(closed, (t) => sessionForDate(new Date(t.traded_at)), (t) => Number(t.net_pnl ?? 0));
  const bySetup = groupSum(
    closed,
    (t: any) => t.playbooks?.setup_name ?? 'Unlinked / no setup',
    (t) => Number(t.net_pnl ?? 0)
  );

  const ruleFollowCounts = { YES: 0, PARTIAL: 0, NO: 0, unspecified: 0 };
  for (const t of closed) {
    if (t.setup_followed === 'YES') ruleFollowCounts.YES++;
    else if (t.setup_followed === 'PARTIAL') ruleFollowCounts.PARTIAL++;
    else if (t.setup_followed === 'NO') ruleFollowCounts.NO++;
    else ruleFollowCounts.unspecified++;
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-2xl font-semibold">Analytics</h1>
      <p className="text-sm text-muted mt-1">
        Computed from {closed.length} closed trade{closed.length === 1 ? '' : 's'}
        {openCount > 0 && ` (${openCount} open trade${openCount === 1 ? '' : 's'} excluded)`}.
        Past performance does not guarantee future results.
      </p>

      {closed.length === 0 ? (
        <Card className="mt-8">
          <p className="text-sm text-muted">Log some closed trades in your journal to see analytics here.</p>
        </Card>
      ) : (
        <>
          <div className="grid md:grid-cols-4 gap-4 mt-8">
            <StatCard label="Net P&L" value={fmt(netPnl)} />
            <StatCard label="Win rate" value={`${wr.toFixed(1)}%`} />
            <StatCard label="Profit factor" value={pf === Infinity ? '∞' : pf.toFixed(2)} />
            <StatCard label="Expectancy / trade" value={fmt(exp)} />
            <StatCard label="Average win" value={fmt(avgWin)} />
            <StatCard label="Average loss" value={fmt(avgLoss)} />
            <StatCard label="Average R-multiple" value={avgR !== null ? avgR.toFixed(2) : '—'} hint={avgR === null ? 'No R-multiples recorded' : undefined} />
            <StatCard label="Max drawdown" value={fmt(dd)} />
          </div>

          <Card className="mt-8">
            <h2 className="font-medium mb-4">Equity curve</h2>
            <EquityCurveChart data={equityCurveData} />
          </Card>

          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <Card>
              <h2 className="font-medium mb-4">Results by model</h2>
              <BreakdownBarChart data={byModel} />
            </Card>
            <Card>
              <h2 className="font-medium mb-4">Results by instrument</h2>
              <BreakdownBarChart data={byInstrument} />
            </Card>
            <Card>
              <h2 className="font-medium mb-4">Results by day of week</h2>
              <BreakdownBarChart data={byDayOfWeek} />
            </Card>
            <Card>
              <h2 className="font-medium mb-4">
                Results by session
                <span className="text-xs text-muted font-normal ml-2">(UTC hour buckets — see README)</span>
              </h2>
              <BreakdownBarChart data={bySession} />
            </Card>
            <Card className="md:col-span-2">
              <h2 className="font-medium mb-4">Results by setup</h2>
              <BreakdownBarChart data={bySetup} />
            </Card>
          </div>

          <Card className="mt-6">
            <h2 className="font-medium mb-4">Rule-following</h2>
            <div className="grid grid-cols-4 gap-4 text-center text-sm">
              <div><p className="text-2xl font-mono text-accent">{ruleFollowCounts.YES}</p><p className="text-muted mt-1">Followed</p></div>
              <div><p className="text-2xl font-mono text-warning">{ruleFollowCounts.PARTIAL}</p><p className="text-muted mt-1">Partial</p></div>
              <div><p className="text-2xl font-mono text-danger">{ruleFollowCounts.NO}</p><p className="text-muted mt-1">Not followed</p></div>
              <div><p className="text-2xl font-mono text-muted">{ruleFollowCounts.unspecified}</p><p className="text-muted mt-1">Unspecified</p></div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
