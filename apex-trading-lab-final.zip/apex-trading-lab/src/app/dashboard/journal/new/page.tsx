import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { TradeForm } from '@/components/journal/trade-form';
import { createTradeAction } from '@/app/actions/journal';

export default async function NewTradePage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/sign-in');

  const { data: playbooks } = await supabase
    .from('playbooks')
    .select('id, setup_name, models(name)')
    .eq('status', 'published')
    .order('setup_name');
  const playbookOptions = (playbooks ?? []).map((p: any) => ({ id: p.id, label: `${p.models?.name ?? ''} — ${p.setup_name}` }));

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="text-2xl font-semibold mb-6">Log a trade</h1>
      <TradeForm userId={user.id} action={createTradeAction} submitLabel="Save trade" playbookOptions={playbookOptions} />
    </div>
  );
}
