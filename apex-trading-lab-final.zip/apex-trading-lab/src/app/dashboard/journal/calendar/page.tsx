import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { startOfMonth, endOfMonth, eachDayOfInterval, format, addMonths, subMonths, isSameMonth } from 'date-fns';

export default async function JournalCalendarPage({ searchParams }: { searchParams: { month?: string } }) {
  const supabase = createClient();
  const anchor = searchParams.month ? new Date(`${searchParams.month}-01`) : new Date();
  const monthStart = startOfMonth(anchor);
  const monthEnd = endOfMonth(anchor);

  const { data: trades } = await supabase
    .from('journal_trades')
    .select('traded_at, net_pnl')
    .gte('traded_at', monthStart.toISOString())
    .lte('traded_at', monthEnd.toISOString());

  const pnlByDay = new Map<string, number>();
  for (const t of trades ?? []) {
    const key = format(new Date(t.traded_at), 'yyyy-MM-dd');
    pnlByDay.set(key, (pnlByDay.get(key) ?? 0) + Number(t.net_pnl ?? 0));
  }

  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const prevMonth = format(subMonths(anchor, 1), 'yyyy-MM');
  const nextMonth = format(addMonths(anchor, 1), 'yyyy-MM');

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{format(anchor, 'MMMM yyyy')}</h1>
        <div className="flex gap-3 text-sm">
          <Link href={`/dashboard/journal/calendar?month=${prevMonth}`} className="text-accent hover:underline">&larr; Prev</Link>
          <Link href="/dashboard/journal" className="text-muted hover:underline">List view</Link>
          <Link href={`/dashboard/journal/calendar?month=${nextMonth}`} className="text-accent hover:underline">Next &rarr;</Link>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2 mt-8 text-xs">
        {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d) => <div key={d} className="text-center text-muted">{d}</div>)}
        {Array.from({ length: days[0].getDay() }).map((_, i) => <div key={`pad-${i}`} />)}
        {days.map((d) => {
          const key = format(d, 'yyyy-MM-dd');
          const pnl = pnlByDay.get(key);
          return (
            <div
              key={key}
              className={`aspect-square rounded-lg border p-2 flex flex-col justify-between text-xs ${
                pnl === undefined ? 'border-border' : pnl >= 0 ? 'border-accent/40 bg-accent/10' : 'border-danger/40 bg-danger/10'
              } ${!isSameMonth(d, anchor) ? 'opacity-30' : ''}`}
            >
              <span className="text-muted">{format(d, 'd')}</span>
              {pnl !== undefined && (
                <span className={pnl >= 0 ? 'text-accent font-mono' : 'text-danger font-mono'}>
                  {pnl.toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
