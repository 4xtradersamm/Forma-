import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import { CsvExportButton } from '@/components/journal/csv-export-button';
import { CsvImportForm } from '@/components/journal/csv-import-form';

const PAGE_SIZE = 20;

export default async function JournalPage({
  searchParams,
}: {
  searchParams: { model?: string; instrument?: string; direction?: string; from?: string; to?: string; page?: string };
}) {
  const supabase = createClient();
  const page = Math.max(1, parseInt(searchParams.page ?? '1', 10) || 1);
  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;

  let query = supabase.from('journal_trades').select('*', { count: 'exact' }).order('traded_at', { ascending: false });

  if (searchParams.model) query = query.eq('model', searchParams.model);
  if (searchParams.direction) query = query.eq('direction', searchParams.direction);
  if (searchParams.instrument) query = query.ilike('instrument', `%${searchParams.instrument}%`);
  if (searchParams.from) query = query.gte('traded_at', searchParams.from);
  if (searchParams.to) query = query.lte('traded_at', searchParams.to);

  const { data: trades, count } = await query.range(from, to);
  const totalPages = Math.max(1, Math.ceil((count ?? 0) / PAGE_SIZE));

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h1 className="text-2xl font-semibold">Trading journal</h1>
        <div className="flex items-center gap-3">
          <Link href="/dashboard/journal/calendar" className="btn-secondary">Calendar view</Link>
          <Link href="/dashboard/journal/new" className="btn-primary">Log a trade</Link>
        </div>
      </div>

      <Card className="mt-6">
        <form className="grid md:grid-cols-5 gap-3" method="get">
          <select name="model" defaultValue={searchParams.model ?? ''} className="rounded-lg border border-border bg-surface px-3 py-2 text-sm">
            <option value="">All models</option>
            <option value="QT">QT</option>
            <option value="GXT">GXT</option>
            <option value="TTFM">TTFM</option>
            <option value="OTHER">Other</option>
          </select>
          <select name="direction" defaultValue={searchParams.direction ?? ''} className="rounded-lg border border-border bg-surface px-3 py-2 text-sm">
            <option value="">Long or short</option>
            <option value="LONG">Long</option>
            <option value="SHORT">Short</option>
          </select>
          <input name="instrument" defaultValue={searchParams.instrument} placeholder="Instrument" className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
          <input name="from" type="date" defaultValue={searchParams.from} className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
          <input name="to" type="date" defaultValue={searchParams.to} className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
          <button type="submit" className="btn-secondary md:col-span-5 md:w-fit">Apply filters</button>
        </form>
      </Card>

      <div className="mt-4 flex items-center gap-3">
        <CsvExportButton />
        <CsvImportForm />
      </div>

      <div className="mt-6 space-y-2">
        {trades && trades.length > 0 ? (
          trades.map((t) => (
            <Link key={t.id} href={`/dashboard/journal/${t.id}`}>
              <Card className="flex items-center justify-between py-3">
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-muted font-mono">{new Date(t.traded_at).toLocaleDateString()}</span>
                  <span className="font-medium">{t.instrument}</span>
                  <span className="text-xs border border-border rounded-full px-2 py-0.5 text-muted">{t.model}</span>
                  <span className="text-xs text-muted">{t.direction}</span>
                  {t.is_open && <span className="text-xs text-warning">OPEN</span>}
                </div>
                <span className={Number(t.net_pnl ?? 0) >= 0 ? 'text-accent font-mono' : 'text-danger font-mono'}>
                  {Number(t.net_pnl ?? 0).toLocaleString(undefined, { style: 'currency', currency: 'USD' })}
                </span>
              </Card>
            </Link>
          ))
        ) : (
          <p className="text-sm text-muted">No trades match these filters.</p>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-6 flex items-center gap-2 text-sm">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <Link
              key={p}
              href={{ pathname: '/dashboard/journal', query: { ...searchParams, page: p } }}
              className={p === page ? 'text-accent font-medium' : 'text-muted hover:text-foreground'}
            >
              {p}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
