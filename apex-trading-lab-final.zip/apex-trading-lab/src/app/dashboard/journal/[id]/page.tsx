import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { TradeForm } from '@/components/journal/trade-form';
import { updateTradeAction, deleteTradeAction } from '@/app/actions/journal';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default async function TradeDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  // RLS `journal: owner only` means this returns null for a trade that isn't the
  // caller's own, even if they guess a valid UUID — notFound() covers both cases.
  const { data: trade } = await supabase.from('journal_trades').select('*').eq('id', params.id).maybeSingle();
  if (!trade) notFound();

  const { data: playbooks } = await supabase
    .from('playbooks')
    .select('id, setup_name, models(name)')
    .eq('status', 'published')
    .order('setup_name');
  const playbookOptions = (playbooks ?? []).map((p: any) => ({ id: p.id, label: `${p.models?.name ?? ''} — ${p.setup_name}` }));

  const screenshotUrls = await Promise.all(
    [trade.screenshot_before_url, trade.screenshot_after_url].map(async (path) => {
      if (!path) return null;
      const { data } = await supabase.storage.from('journal-screenshots').createSignedUrl(path, 3600);
      return data?.signedUrl ?? null;
    })
  );

  const boundUpdate = updateTradeAction.bind(null, params.id);

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">{trade.instrument} — {new Date(trade.traded_at).toLocaleDateString()}</h1>
        <form action={deleteTradeAction.bind(null, params.id)}>
          <Button type="submit" variant="danger">Delete</Button>
        </form>
      </div>

      {(screenshotUrls[0] || screenshotUrls[1]) && (
        <div className="grid md:grid-cols-2 gap-4 mb-8">
          {screenshotUrls[0] && (
            <Card>
              <p className="label-muted mb-2">Before entry</p>
              <img src={screenshotUrls[0]} alt="Before entry" className="rounded-lg w-full" />
            </Card>
          )}
          {screenshotUrls[1] && (
            <Card>
              <p className="label-muted mb-2">After exit</p>
              <img src={screenshotUrls[1]} alt="After exit" className="rounded-lg w-full" />
            </Card>
          )}
        </div>
      )}

      <TradeForm userId={user.id} defaults={trade} action={boundUpdate} submitLabel="Save changes" playbookOptions={playbookOptions} />
    </div>
  );
}
