import { createClient } from '@/lib/supabase/server';
import { AccountForm } from '@/components/dashboard/account-form';
import { Card } from '@/components/ui/card';
import { signOutAction } from '@/app/actions/auth';
import { openBillingPortalAction, cancelRazorpaySubscriptionAction } from '@/app/actions/billing';
import { Button } from '@/components/ui/button';

export default async function AccountPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const [{ data: profile }, { data: subscription }] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).single(),
    supabase.from('subscriptions').select('*, membership_plans(name, interval, price_cents, currency)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(1).maybeSingle(),
  ]);

  return (
    <div className="mx-auto max-w-2xl px-6 py-12 space-y-6">
      <h1 className="text-2xl font-semibold">Account settings</h1>

      <Card>
        <h2 className="font-medium mb-4">Profile</h2>
        <p className="text-sm text-muted mb-4">{user.email}</p>
        <AccountForm defaultName={profile?.display_name ?? ''} />
      </Card>

      <Card>
        <h2 className="font-medium mb-2">Membership</h2>
        {subscription ? (
          <div className="text-sm text-muted space-y-1">
            <p>Plan: {subscription.membership_plans?.name ?? 'Paid'}</p>
            <p>Status: {subscription.status}{subscription.cancel_at_period_end && ' (cancels at period end)'}</p>
            {subscription.current_period_end && (
              <p>Renews/ends: {new Date(subscription.current_period_end).toLocaleDateString()}</p>
            )}
            <div className="pt-3">
              {subscription.provider === 'stripe' && (
                <form action={openBillingPortalAction}>
                  <Button type="submit" variant="secondary">Manage billing</Button>
                </form>
              )}
              {subscription.provider === 'razorpay' && !subscription.cancel_at_period_end && (
                <form action={cancelRazorpaySubscriptionAction}>
                  <Button type="submit" variant="secondary">Cancel subscription</Button>
                </form>
              )}
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted">You&apos;re on the free plan.</p>
        )}
      </Card>

      <form action={signOutAction}>
        <Button type="submit" variant="secondary">Sign out</Button>
      </form>
    </div>
  );
}
