import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';

// RLS already filters to published courses (and further to non-paid courses for
// free users at the lesson level) — this query returns exactly what this user
// is allowed to see, no app-side filtering needed for visibility.
export default async function LearnPage() {
  const supabase = createClient();
  const { data: courses } = await supabase
    .from('courses')
    .select('*, models(name, slug)')
    .order('sort_order');

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-3xl font-semibold">Courses</h1>
      <p className="text-sm text-muted mt-2">Structured lessons for QT, GXT, TTFM, and general trading fundamentals.</p>

      <div className="mt-8 grid md:grid-cols-2 gap-6">
        {courses && courses.length > 0 ? (
          courses.map((c: any) => (
            <Link key={c.id} href={`/learn/${c.id}`}>
              <Card className="h-full hover:border-accent/50 transition-colors">
                <div className="flex items-center justify-between">
                  <p className="label-muted">{c.models?.name ?? 'General'}</p>
                  {c.is_paid && <span className="text-xs border border-accent/40 text-accent rounded-full px-2 py-0.5">Paid</span>}
                </div>
                <h2 className="font-medium mt-1">{c.title}</h2>
                {c.description && <p className="text-sm text-muted mt-2">{c.description}</p>}
              </Card>
            </Link>
          ))
        ) : (
          <p className="text-sm text-muted">No courses published yet.</p>
        )}
      </div>
    </div>
  );
}
