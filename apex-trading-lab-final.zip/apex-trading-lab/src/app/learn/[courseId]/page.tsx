import Link from 'next/link';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';

export default async function CoursePage({ params }: { params: { courseId: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: course } = await supabase.from('courses').select('*, models(name)').eq('id', params.courseId).maybeSingle();
  if (!course) notFound();

  const { data: modules } = await supabase
    .from('modules')
    .select('*, lessons(id, title, is_paid, sort_order)')
    .eq('course_id', params.courseId)
    .order('sort_order');

  let completedLessonIds = new Set<string>();
  if (user) {
    const { data: progress } = await supabase
      .from('lesson_progress')
      .select('lesson_id')
      .eq('user_id', user.id)
      .not('completed_at', 'is', null);
    completedLessonIds = new Set((progress ?? []).map((p) => p.lesson_id));
  }

  const totalLessons = (modules ?? []).reduce((sum, m: any) => sum + (m.lessons?.length ?? 0), 0);
  const completedCount = (modules ?? []).reduce(
    (sum, m: any) => sum + (m.lessons ?? []).filter((l: any) => completedLessonIds.has(l.id)).length,
    0
  );

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <p className="label-muted">{course.models?.name ?? 'General'}</p>
      <h1 className="text-3xl font-semibold mt-2">{course.title}</h1>
      {course.description && <p className="text-muted mt-3">{course.description}</p>}

      {totalLessons > 0 && (
        <div className="mt-4 flex items-center gap-3 text-sm text-muted">
          <div className="w-40 h-1.5 bg-border rounded-full overflow-hidden">
            <div className="h-full bg-accent" style={{ width: `${(completedCount / totalLessons) * 100}%` }} />
          </div>
          <span>{completedCount}/{totalLessons} lessons complete</span>
        </div>
      )}

      <div className="mt-8 space-y-6">
        {(modules ?? []).map((m: any) => (
          <div key={m.id}>
            <h2 className="font-medium mb-3">{m.title}</h2>
            <div className="space-y-2">
              {(m.lessons ?? [])
                .sort((a: any, b: any) => a.sort_order - b.sort_order)
                .map((l: any) => (
                  <Link key={l.id} href={`/learn/${params.courseId}/${l.id}`}>
                    <Card className="flex items-center justify-between py-3">
                      <span className="text-sm">
                        {completedLessonIds.has(l.id) && <span className="text-accent mr-2">✓</span>}
                        {l.title}
                      </span>
                      {l.is_paid && <span className="text-xs text-muted">Paid</span>}
                    </Card>
                  </Link>
                ))}
            </div>
          </div>
        ))}
        {(!modules || modules.length === 0) && <p className="text-sm text-muted">No modules published yet.</p>}
      </div>
    </div>
  );
}
