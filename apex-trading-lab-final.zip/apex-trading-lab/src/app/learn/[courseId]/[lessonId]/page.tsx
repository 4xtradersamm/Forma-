import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { LessonActions } from '@/components/education/lesson-actions';
import { trackLessonViewAction } from '@/app/actions/education';

export default async function LessonPage({ params }: { params: { courseId: string; lessonId: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // RLS enforces paid-lesson gating here: if this lesson is paid and the user
  // isn't a paid member, this query returns null (not an error) and we 404 —
  // no separate "is this paid" check needed in application code.
  const { data: lesson } = await supabase.from('lessons').select('*').eq('id', params.lessonId).maybeSingle();
  if (!lesson) notFound();

  let isCompleted = false;
  let isBookmarked = false;
  if (user) {
    await trackLessonViewAction(lesson.id);
    const [{ data: progress }, { data: bookmark }] = await Promise.all([
      supabase.from('lesson_progress').select('completed_at').eq('user_id', user.id).eq('lesson_id', lesson.id).maybeSingle(),
      supabase.from('bookmarks').select('lesson_id').eq('user_id', user.id).eq('lesson_id', lesson.id).maybeSingle(),
    ]);
    isCompleted = !!progress?.completed_at;
    isBookmarked = !!bookmark;
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-3xl font-semibold">{lesson.title}</h1>

      {lesson.video_url && (
        <div className="mt-6 aspect-video rounded-xl overflow-hidden border border-border">
          <iframe src={lesson.video_url} className="w-full h-full" allowFullScreen title={lesson.title} />
        </div>
      )}

      <div className="mt-6 text-sm text-muted whitespace-pre-line leading-relaxed">
        {lesson.body || '[Placeholder — lesson content not yet added.]'}
      </div>

      {lesson.resources && lesson.resources.length > 0 && (
        <div className="mt-6">
          <h2 className="font-medium">Resources</h2>
          <ul className="mt-2 space-y-1 text-sm">
            {(lesson.resources as Array<{ name: string; url: string }>).map((r) => (
              <li key={r.url}>
                <a href={r.url} className="text-accent hover:underline" target="_blank" rel="noreferrer">{r.name}</a>
              </li>
            ))}
          </ul>
        </div>
      )}

      {user && (
        <div className="mt-10">
          <LessonActions
            lessonId={lesson.id}
            courseId={params.courseId}
            initiallyCompleted={isCompleted}
            initiallyBookmarked={isBookmarked}
          />
        </div>
      )}
    </div>
  );
}
