import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/card';
import Link from 'next/link';

// Live-session join links and paid announcements are already filtered by RLS —
// a row that's paid-only simply doesn't come back for a free/anonymous visitor,
// so there's no separate "hide the join link" logic needed here.
export default async function CommunityPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const [{ data: announcements }, { data: upcoming }, { data: replays }] = await Promise.all([
    supabase.from('announcements').select('*').not('published_at', 'is', null).order('published_at', { ascending: false }).limit(10),
    supabase.from('live_sessions').select('*').gte('starts_at', new Date().toISOString()).order('starts_at', { ascending: true }),
    supabase.from('live_sessions').select('*').not('replay_url', 'is', null).order('starts_at', { ascending: false }).limit(10),
  ]);

  return (
    <div className="mx-auto max-w-4xl px-6 py-16 space-y-10">
      <div>
        <h1 className="text-3xl font-semibold">Community</h1>
        <p className="text-sm text-muted mt-2">Announcements, live sessions, and replays.</p>
      </div>

      <section>
        <h2 className="font-medium mb-4">Announcements</h2>
        <div className="space-y-3">
          {announcements && announcements.length > 0 ? (
            announcements.map((a) => (
              <Card key={a.id}>
                <p className="font-medium">{a.title}</p>
                <p className="text-sm text-muted mt-1">{a.body}</p>
                <p className="text-xs text-muted mt-2">{new Date(a.published_at).toLocaleDateString()}</p>
              </Card>
            ))
          ) : (
            <p className="text-sm text-muted">No announcements yet.</p>
          )}
        </div>
      </section>

      <section>
        <h2 className="font-medium mb-4">Upcoming live sessions</h2>
        <div className="space-y-3">
          {upcoming && upcoming.length > 0 ? (
            upcoming.map((s) => (
              <Card key={s.id} className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{s.title}</p>
                  {s.description && <p className="text-sm text-muted mt-1">{s.description}</p>}
                  <p className="text-xs text-muted mt-2">{new Date(s.starts_at).toLocaleString()}</p>
                </div>
                {s.join_url ? (
                  <a href={s.join_url} target="_blank" rel="noreferrer" className="btn-primary text-sm px-4 py-2">Join</a>
                ) : !user ? (
                  <Link href="/sign-in" className="btn-secondary text-sm px-4 py-2">Sign in</Link>
                ) : (
                  <Link href="/pricing" className="btn-secondary text-sm px-4 py-2">Upgrade</Link>
                )}
              </Card>
            ))
          ) : (
            <p className="text-sm text-muted">No upcoming sessions scheduled.</p>
          )}
        </div>
      </section>

      <section>
        <h2 className="font-medium mb-4">Replay library</h2>
        <div className="space-y-3">
          {replays && replays.length > 0 ? (
            replays.map((s) => (
              <Card key={s.id} className="flex items-center justify-between">
                <p className="font-medium">{s.title}</p>
                <a href={s.replay_url!} target="_blank" rel="noreferrer" className="text-accent text-sm hover:underline">Watch replay</a>
              </Card>
            ))
          ) : (
            <p className="text-sm text-muted">No replays yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}
