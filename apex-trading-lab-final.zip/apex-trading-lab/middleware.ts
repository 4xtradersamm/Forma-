import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';

// Server-enforced route protection. Frontend hiding of buttons/pages is NOT
// sufficient — this is the actual authorization boundary for protected routes.
const PAID_ROUTES = ['/dashboard/journal', '/dashboard/backtesting', '/models/qt/playbooks', '/models/gxt/playbooks', '/models/ttfm/playbooks'];
const AUTH_ROUTES = ['/dashboard'];
const ADMIN_ROUTES = ['/admin'];

export async function middleware(request: NextRequest) {
  const { response, user, supabase } = await updateSession(request);
  const path = request.nextUrl.pathname;

  const needsAuth = AUTH_ROUTES.some((p) => path.startsWith(p)) || ADMIN_ROUTES.some((p) => path.startsWith(p));
  if (needsAuth && !user) {
    const url = request.nextUrl.clone();
    url.pathname = '/sign-in';
    url.searchParams.set('redirect', path);
    return NextResponse.redirect(url);
  }

  if (ADMIN_ROUTES.some((p) => path.startsWith(p)) && user) {
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
    if (profile?.role !== 'admin') {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }

  if (PAID_ROUTES.some((p) => path.startsWith(p)) && user) {
    const { data: sub } = await supabase
      .from('subscriptions')
      .select('status, current_period_end')
      .eq('user_id', user.id)
      .in('status', ['active', 'trialing'])
      .maybeSingle();
    const isPaid = !!sub;
    if (!isPaid) {
      const url = request.nextUrl.clone();
      url.pathname = '/pricing';
      url.searchParams.set('reason', 'upgrade-required');
      return NextResponse.redirect(url);
    }
  }

  return response;
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*', '/models/:path*'],
};
