-- Storage buckets for screenshots and lesson media.
-- Run in Supabase SQL editor (storage schema already exists).

insert into storage.buckets (id, name, public)
values
  ('journal-screenshots', 'journal-screenshots', false),
  ('lesson-media', 'lesson-media', true),
  ('chart-images', 'chart-images', true)
on conflict (id) do nothing;

-- Journal screenshots: private, path convention is `${user_id}/${filename}`
create policy "journal-screenshots: owner can read own"
  on storage.objects for select
  using (bucket_id = 'journal-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "journal-screenshots: owner can upload own"
  on storage.objects for insert
  with check (bucket_id = 'journal-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "journal-screenshots: owner can delete own"
  on storage.objects for delete
  using (bucket_id = 'journal-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);

-- Lesson media / chart images: public read, admin-only write (checked via is_admin()).
create policy "lesson-media: public read"
  on storage.objects for select
  using (bucket_id = 'lesson-media');

create policy "lesson-media: admin write"
  on storage.objects for insert
  with check (bucket_id = 'lesson-media' and public.is_admin());

create policy "chart-images: public read"
  on storage.objects for select
  using (bucket_id = 'chart-images');

create policy "chart-images: admin write"
  on storage.objects for insert
  with check (bucket_id = 'chart-images' and public.is_admin());
