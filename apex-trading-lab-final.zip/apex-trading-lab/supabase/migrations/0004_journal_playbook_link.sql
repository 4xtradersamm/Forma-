-- Links a journal trade to the specific playbook/setup it was based on, so
-- "results by setup" in analytics can be a real join instead of guessing from
-- freeform tags. Nullable: a trade doesn't have to reference a published setup.
alter table public.journal_trades
  add column playbook_id uuid references public.playbooks(id) on delete set null;

create index on public.journal_trades (playbook_id);
