-- Apex Trading Lab: initial schema
-- Run via `supabase db push` or paste into Supabase SQL editor.
-- Assumes Supabase auth.users already exists.

create extension if not exists "pgcrypto";

-- =========================================================
-- ROLES
-- =========================================================
create type user_role as enum ('free', 'paid', 'admin');
create type trade_model as enum ('QT', 'GXT', 'TTFM', 'OTHER');
create type trade_direction as enum ('LONG', 'SHORT');
create type rule_follow as enum ('YES', 'NO', 'PARTIAL');
create type content_status as enum ('draft', 'published', 'archived');
create type subscription_status as enum ('active', 'trialing', 'past_due', 'canceled', 'incomplete');
create type billing_interval as enum ('monthly', 'annual');

-- =========================================================
-- PROFILES  (1:1 with auth.users)
-- =========================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  role user_role not null default 'free',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Auto-create a profile row on signup
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, split_part(new.email, '@', 1));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =========================================================
-- MEMBERSHIP PLANS & SUBSCRIPTIONS
-- =========================================================
create table public.membership_plans (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  interval billing_interval not null,
  price_cents integer not null check (price_cents >= 0),
  currency text not null default 'USD',
  features jsonb not null default '[]',
  is_active boolean not null default true,
  provider text not null default 'stripe', -- 'stripe' | 'razorpay'
  provider_price_id text,
  created_at timestamptz not null default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id uuid references public.membership_plans(id),
  status subscription_status not null,
  provider text not null,
  provider_customer_id text,
  provider_subscription_id text,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.subscriptions (user_id);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null unique, -- enforces webhook idempotency
  event_type text not null,
  raw_payload jsonb not null,
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

-- =========================================================
-- MODELS / EDUCATION SYSTEM
-- =========================================================
create table public.models (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug in ('qt','gxt','ttfm')),
  name text not null,
  overview text,
  prerequisites text,
  status content_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  model_id uuid references public.models(id) on delete set null,
  title text not null,
  description text,
  is_paid boolean not null default false,
  status content_status not null default 'draft',
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  sort_order integer not null default 0
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  title text not null,
  body text,               -- markdown/rich text
  video_url text,
  resources jsonb not null default '[]', -- [{name,url,type}]
  is_paid boolean not null default false,
  prerequisite_lesson_id uuid references public.lessons(id),
  sort_order integer not null default 0,
  status content_status not null default 'draft',
  created_at timestamptz not null default now()
);

create table public.lesson_progress (
  user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz,
  last_viewed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table public.bookmarks (
  user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

-- =========================================================
-- PLAYBOOKS (setup library per model) — placeholders only
-- =========================================================
create table public.playbooks (
  id uuid primary key default gen_random_uuid(),
  model_id uuid not null references public.models(id) on delete cascade,
  setup_name text not null,
  market_tags text[] not null default '{}',
  timeframe_tags text[] not null default '{}',
  session_tags text[] not null default '{}',
  market_conditions text,
  prerequisites text,
  entry_conditions text,
  stop_loss_rules text,
  take_profit_rules text,
  invalidation_conditions text,
  risk_management_rules text,
  common_mistakes text,
  faq jsonb not null default '[]',
  chart_image_urls text[] not null default '{}',
  is_verified_rule boolean not null default false, -- false = placeholder, not yet confirmed by owner
  status content_status not null default 'draft',
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- =========================================================
-- TRADING JOURNAL
-- =========================================================
create table public.journal_trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  instrument text not null,
  market text,
  traded_at timestamptz not null,
  model trade_model not null default 'OTHER',
  direction trade_direction not null,
  entry_price numeric,
  stop_loss_price numeric,
  take_profit_price numeric,
  exit_price numeric,
  position_size numeric,
  risk_amount numeric,
  gross_pnl numeric,
  fees numeric not null default 0,
  net_pnl numeric generated always as (coalesce(gross_pnl,0) - coalesce(fees,0)) stored,
  r_multiple numeric,
  screenshot_before_url text,
  screenshot_after_url text,
  setup_followed rule_follow,
  emotional_state text,
  mistakes text,
  notes text,
  tags text[] not null default '{}',
  is_open boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.journal_trades (user_id, traded_at desc);
create index on public.journal_trades (user_id, model);

-- =========================================================
-- BACKTESTING JOURNAL (manual, per model)
-- =========================================================
create table public.backtest_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  model trade_model not null,
  instrument text not null,
  timeframe text not null,
  date_range_start date,
  date_range_end date,
  created_at timestamptz not null default now()
);

create table public.backtest_trades (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.backtest_sessions(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  setup_date date not null,
  entry_price numeric,
  stop_loss_price numeric,
  take_profit_price numeric,
  outcome text, -- 'win' | 'loss' | 'breakeven' | 'invalid'
  r_multiple numeric,
  all_rules_satisfied boolean not null default false,
  chart_image_url text,
  notes text,
  created_at timestamptz not null default now()
);
create index on public.backtest_trades (session_id);

-- =========================================================
-- COMMUNITY / LIVE SESSIONS
-- =========================================================
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  is_paid_only boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.live_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  starts_at timestamptz not null,
  ends_at timestamptz,
  is_paid_only boolean not null default true,
  join_url text, -- secure link, only exposed to authorized members via RLS-protected query
  replay_url text,
  created_at timestamptz not null default now()
);

-- =========================================================
-- updated_at trigger helper
-- =========================================================
create function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger set_updated_at before update on public.profiles
  for each row execute procedure public.set_updated_at();
create trigger set_updated_at before update on public.subscriptions
  for each row execute procedure public.set_updated_at();
create trigger set_updated_at before update on public.models
  for each row execute procedure public.set_updated_at();
create trigger set_updated_at before update on public.playbooks
  for each row execute procedure public.set_updated_at();
create trigger set_updated_at before update on public.journal_trades
  for each row execute procedure public.set_updated_at();

