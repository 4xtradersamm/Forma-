-- Needed for idempotent webhook upserts (ON CONFLICT (provider_subscription_id)).
-- Postgres unique constraints allow multiple NULLs, so this doesn't block rows
-- that haven't been linked to a provider subscription yet.
alter table public.subscriptions
  add constraint subscriptions_provider_subscription_id_key unique (provider_subscription_id);
