-- Apex Trading Lab: Row Level Security policies
-- Run after 0001_init.sql

-- Helper: is the current user an admin?
create function public.is_admin()
returns boolean as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$ language sql stable security definer;

-- Helper: does the current user have an active paid subscription?
create function public.is_paid_member()
returns boolean as $$
  select public.is_admin() or exists (
    select 1 from public.subscriptions
    where user_id = auth.uid()
      and status in ('active','trialing')
      and (current_period_end is null or current_period_end > now())
  );
$$ language sql stable security definer;

-- =========================================================
-- PROFILES
-- =========================================================
alter table public.profiles enable row level security;

create policy "profiles: user reads own" on public.profiles
  for select using (auth.uid() = id or public.is_admin());

create policy "profiles: user updates own (non-role fields enforced in app layer)" on public.profiles
  for update using (auth.uid() = id or public.is_admin());

-- Never allow a non-admin to escalate their own role via API/PostgREST.
-- Enforced by revoking column-level UPDATE on `role` from anon/authenticated.
revoke update (role) on public.profiles from authenticated;
grant update (role) on public.profiles to service_role;

-- =========================================================
-- MEMBERSHIP PLANS (public read, admin write)
-- =========================================================
alter table public.membership_plans enable row level security;
create policy "plans: public can read active plans" on public.membership_plans
  for select using (is_active = true or public.is_admin());
create policy "plans: admin manages" on public.membership_plans
  for all using (public.is_admin()) with check (public.is_admin());

-- =========================================================
-- SUBSCRIPTIONS (owner + admin only; writes via service role / webhooks only)
-- =========================================================
alter table public.subscriptions enable row level security;
create policy "subs: user reads own" on public.subscriptions
  for select using (auth.uid() = user_id or public.is_admin());
create policy "subs: admin writes" on public.subscriptions
  for all using (public.is_admin()) with check (public.is_admin());
-- Note: webhook handler uses the service-role key (bypasses RLS) to insert/update
-- subscription rows after verifying the provider signature. Never do this from the client.

-- =========================================================
-- PAYMENT EVENTS (service role / admin only — never client-writable)
-- =========================================================
alter table public.payment_events enable row level security;
create policy "payment_events: admin reads" on public.payment_events
  for select using (public.is_admin());
-- No insert/update/delete policy for authenticated/anon => only service_role (bypasses RLS) can write.

-- =========================================================
-- MODELS / COURSES / MODULES (public read if published, admin write)
-- =========================================================
alter table public.models enable row level security;
create policy "models: public reads published" on public.models
  for select using (status = 'published' or public.is_admin());
create policy "models: admin manages" on public.models
  for all using (public.is_admin()) with check (public.is_admin());

alter table public.courses enable row level security;
create policy "courses: public reads published" on public.courses
  for select using (status = 'published' or public.is_admin());
create policy "courses: admin manages" on public.courses
  for all using (public.is_admin()) with check (public.is_admin());

alter table public.modules enable row level security;
create policy "modules: read follows parent course" on public.modules
  for select using (
    public.is_admin() or exists (
      select 1 from public.courses c
      where c.id = course_id and c.status = 'published'
    )
  );
create policy "modules: admin manages" on public.modules
  for all using (public.is_admin()) with check (public.is_admin());

-- =========================================================
-- LESSONS — free lessons: any signed-in user; paid lessons: paid members only
-- =========================================================
alter table public.lessons enable row level security;
create policy "lessons: read access rules" on public.lessons
  for select using (
    public.is_admin()
    or (
      status = 'published'
      and (is_paid = false or public.is_paid_member())
    )
  );
create policy "lessons: admin manages" on public.lessons
  for all using (public.is_admin()) with check (public.is_admin());

alter table public.lesson_progress enable row level security;
create policy "lesson_progress: owner only" on public.lesson_progress
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

alter table public.bookmarks enable row level security;
create policy "bookmarks: owner only" on public.bookmarks
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- =========================================================
-- PLAYBOOKS — same free/paid pattern, gated by parent course-less model directly
-- (playbooks are tied to a model, not a course; treat all as "paid" content unless flagged)
-- =========================================================
alter table public.playbooks enable row level security;
create policy "playbooks: read access rules" on public.playbooks
  for select using (
    public.is_admin()
    or (status = 'published' and public.is_paid_member())
  );
create policy "playbooks: admin manages" on public.playbooks
  for all using (public.is_admin()) with check (public.is_admin());

-- =========================================================
-- JOURNAL TRADES — strictly private to the owner
-- =========================================================
alter table public.journal_trades enable row level security;
create policy "journal: owner only" on public.journal_trades
  for all using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id);

-- =========================================================
-- BACKTESTING — strictly private to the owner
-- =========================================================
alter table public.backtest_sessions enable row level security;
create policy "backtest_sessions: owner only" on public.backtest_sessions
  for all using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id);

alter table public.backtest_trades enable row level security;
create policy "backtest_trades: owner only" on public.backtest_trades
  for all using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id);

-- =========================================================
-- ANNOUNCEMENTS / LIVE SESSIONS
-- =========================================================
alter table public.announcements enable row level security;
create policy "announcements: read access rules" on public.announcements
  for select using (
    public.is_admin()
    or (published_at is not null and (is_paid_only = false or public.is_paid_member()))
  );
create policy "announcements: admin manages" on public.announcements
  for all using (public.is_admin()) with check (public.is_admin());

alter table public.live_sessions enable row level security;
-- join_url/replay_url are sensitive: expose base metadata to everyone,
-- but the app layer should select join_url only for authorized members.
-- Simplest safe RLS: only paid members (or admins) can read paid-only rows at all.
create policy "live_sessions: read access rules" on public.live_sessions
  for select using (
    public.is_admin()
    or (is_paid_only = false or public.is_paid_member())
  );
create policy "live_sessions: admin manages" on public.live_sessions
  for all using (public.is_admin()) with check (public.is_admin());

