# Apex Trading Lab

A trading education + analytics platform scaffold for the QT, GXT, and TTFM models.
Temporary brand name — rename freely (see "Rebranding" below).

## What's built in this pass (Phase 1: Foundation)

- Next.js 14 (App Router) + TypeScript + Tailwind project structure
- Design system: dark charcoal background, white type, single emerald accent (`tailwind.config.ts`)
- Full Postgres schema for every feature you specified: profiles, roles, subscriptions,
  membership plans, payment events, models/courses/modules/lessons, lesson progress,
  bookmarks, playbooks, journal trades, backtesting sessions/trades, announcements,
  live sessions (`supabase/migrations/0001_init.sql`)
- Row Level Security policies enforcing: journal/backtesting data is owner-only,
  paid content requires an active subscription, admin-only writes for content tables,
  webhook/payment tables are service-role-only (`supabase/migrations/0002_rls.sql`)
- Storage buckets + policies for private journal screenshots and public lesson/chart media
  (`supabase/migrations/0003_storage.sql`)
- Supabase client setup (browser, server, service-role) and session-refresh middleware
- Server-enforced route protection for `/dashboard`, `/admin`, and paid model routes
  (`middleware.ts`) — this is real authorization, not just hidden buttons
- Public pages: Home, QT/GXT/TTFM model pages (placeholder content, clearly flagged),
  Pricing (reads live from `membership_plans`, nothing hardcoded), About, and all four
  legal template pages
- Calculator and analytics formulas as pure, unit-testable functions
  (`src/lib/finance/calculators.ts`, `src/lib/finance/analytics.ts`) — verified against
  known inputs including empty-dataset and zero-denominator edge cases

## Phase 2 & 3 additions (this pass)

- Full auth flow: sign-up, sign-in, forgot-password, reset-password — all backed by
  Zod-validated **server actions** (`src/app/actions/auth.ts`), not client-only validation
- Email verification via `/auth/callback` route handler (exchanges Supabase's auth code
  for a session)
- Sign-in never reveals whether the email or password was wrong; forgot-password never
  reveals whether an account exists for a given email
- Member dashboard (`/dashboard`) — a Server Component whose queries run under the
  signed-in user's session, so Postgres RLS (not app logic) restricts every result to
  their own data: membership status, recent journal entries, recently/currently viewed
  lessons, bookmarks, announcements, quick links
- Account settings (`/dashboard/account`) — update display name, view membership/billing
  status, sign out. The `role` column cannot be changed by this form even if tampered
  with — the database itself revokes `UPDATE` on that column for authenticated users
  (enforced in `0002_rls.sql`, not just in this form)
- Shared UI primitives (`Button`, `Input`, `Label`, `FieldError`, `Card`, `StatCard`)
  used across auth and dashboard, so later phases (journal, calculators, admin) reuse
  the same components rather than re-styling from scratch

I verified (in this sandbox, without a live `next dev` server) that every `@/`-aliased
import in `src/` resolves to a real file, and every `page.tsx`/`route.ts` has the export
Next.js requires. That's not a substitute for `npm run build` — do that yourself before
deploying — but it catches the class of error I could introduce while hand-writing files
without a bundler to check my work.

## Phase 4 & 5 additions (this pass)

- **Playbook admin CRUD** (`/admin/playbooks`): create, edit, publish, unpublish, archive,
  delete. Every field is an optional textarea defaulting to blank with a placeholder
  reminding the admin never to invent a rule. An `is_verified_rule` checkbox tracks
  placeholder vs. final content, and the public list/detail pages surface that flag as a
  visible "placeholder" badge. Deletes and publishes are separate server actions
  (`src/app/actions/playbooks.ts`), guarded by `requireAdmin()` *and* backstopped by the
  `playbooks: admin manages` RLS policy already in `0002_rls.sql` — so even a bug in the
  guard couldn't let a non-admin write.
- **Public playbook library** (`/models/{qt,gxt,ttfm}/playbooks`): lists published setups
  only; detail pages render every field with a print-friendly checklist button (browser
  print, no extra dependency). These routes are already in `middleware.ts`'s `PAID_ROUTES`
  list from Phase 1, so unpaid users are redirected to `/pricing` before the page even
  renders.
- **Admin overview** (`/admin`): live counts (users, active paid members, playbooks,
  journal trades) pulled directly from the database — no placeholder numbers.
- **Education system UI** (`/learn`): course catalog, course detail with module/lesson
  list and a real progress bar, and a lesson page with video embed, resources, a
  "mark complete" button, and a bookmark toggle. Paid-lesson gating needs no extra
  application code — the RLS policy on `lessons` already returns nothing for a paid
  lesson a free user queries, so the page just 404s the way it would for any missing row.

I re-ran the same static checks as last pass (every `@/` import resolves, every
`page.tsx`/`route.ts` has its required export) after adding ~20 new files — still clean.
That's still not `npm run build`; run that yourself once you have network access.

## Phase 6 additions (this pass): Trading journal

- Full CRUD at `/dashboard/journal` — create, edit, delete — with every field from your
  spec (instrument, model, direction, entry/stop/target/exit, position size, risk amount,
  gross P&L, fees, **auto-computed net P&L** via a Postgres generated column so it can
  never drift out of sync with gross P&L/fees, R-multiple, rule-adherence, emotional
  state, mistakes, notes, tags)
- Filters (model, direction, instrument, date range) via URL search params, pagination,
  and a calendar view (`/dashboard/journal/calendar`) showing daily net P&L
- CSV export (client-side, pulls the signed-in user's own trades via RLS, downloads
  instantly) and CSV import (parses client-side with Papaparse, **re-validates every row
  through the same Zod schema the manual form uses** before any insert — invalid rows are
  skipped and reported, never silently coerced)
- Private screenshot uploads (before-entry / after-exit) straight to the
  `journal-screenshots` bucket from Phase 1, in the user's own folder; the detail page
  renders them via short-lived signed URLs rather than public links, since the bucket is
  private by design
- Ownership is enforced twice: the RLS `journal: owner only` policy from Phase 1 is the
  real boundary (a forged request for someone else's trade ID just returns nothing), and
  every insert also explicitly sets `user_id` from the session as a second layer

## Phase 7 additions (this pass): Analytics dashboard + Calculators

- **Schema addition**: `journal_trades.playbook_id` (nullable FK to `playbooks`,
  `supabase/migrations/0004_journal_playbook_link.sql`) — needed so "results by setup"
  is a real join instead of guessing from freeform tags. Run this migration too.
- **Analytics dashboard** (`/dashboard/analytics`): net P&L, win rate, profit factor,
  expectancy, average win/loss, average R-multiple, max drawdown, an equity curve, and
  breakdowns by model / instrument / day of week / trading session / setup, plus a
  rule-following summary — all computed from the `journal_trades` formulas written and
  verified back in Phase 1 (`src/lib/finance/analytics.ts`), now actually wired to
  Recharts. Open trades are explicitly excluded from every stat (documented in the page),
  and an empty journal shows a clear empty state rather than zeros that look like real data.
  **Note on "session"**: your original trades schema had no session field, so sessions
  are derived from UTC-hour buckets (`src/lib/finance/session.ts`) — a documented
  approximation, not official exchange session data. Adjust the boundaries there if your
  markets differ.
- **Calculators** (`/dashboard/calculators`): all five tools from your spec — position
  size, risk/reward, risk-per-trade, percentage risk, daily loss limit — as live,
  client-side forms wired to the same pure functions from Phase 1
  (`src/lib/finance/calculators.ts`). Contract tick size/tick value and account currency
  are all user-configurable inputs, never hardcoded assumptions.

I re-verified the position-size formula against a worked example (NQ, 40-tick stop,
$5/tick, 1% of a $10k account) by hand with Node — it correctly floors to 0 contracts
rather than over-risking when the stop is too wide for the risk budget, which is the
kind of edge case that's easy to get wrong.

## Phase 8 & 9 additions (this pass): Backtesting journal + Community

- **Backtesting journal** (`/dashboard/backtesting`): create a session (model, instrument,
  timeframe, date range), add hypothetical setups (date, entry/stop/target, outcome,
  R-multiple, chart screenshot, whether every model rule was satisfied, notes), CSV
  export per session. Win rate/profit factor/expectancy/avg R-multiple reuse the exact
  same formulas from `src/lib/finance/analytics.ts` — with **R-multiple standing in for
  "net P&L"**, since backtest trades are hypothetical and have no real currency result.
  The sessions list also compares QT/GXT/TTFM against each other in aggregate, per your
  "compare results between models" requirement. Nothing here invents entry conditions —
  every setup is something the user records by hand.
- **Community** (`/community`, public): announcement feed, upcoming live sessions with a
  join link, and a replay library. Deliberately simple — no discussion threads/forum yet,
  per your explicit instruction not to over-build the first version. Paid-only sessions
  and their join URLs are invisible to free/anonymous visitors purely because the RLS
  policy from Phase 1 doesn't return those rows to them — there's no separate
  "hide the link" logic to get wrong.

## Phase 10 additions (this pass): Payments

- **Unified checkout** (`POST /api/checkout`): looks up the selected plan's `provider`
  column (set by an admin — `stripe` or `razorpay`) and creates the right kind of
  session server-side. The client never chooses the provider.
- **Stripe**: Checkout Session in subscription mode
  (`src/app/api/checkout/route.ts`) → redirect to Stripe's hosted page. Webhook at
  `POST /api/webhooks/stripe` verifies the signature via `stripe.webhooks.constructEvent`
  before touching anything, handles `checkout.session.completed`,
  `customer.subscription.updated/deleted`, and `invoice.payment_failed`, and writes
  subscription state with the **service-role client** (the one place in this codebase
  that's supposed to bypass RLS, since there's no user session in a webhook request).
  "Manage billing" in account settings hands off to Stripe's own hosted billing portal
  rather than reimplementing cancellation/plan-change UI.
- **Razorpay**: creates a Subscription via their API, then the client opens Razorpay's
  hosted checkout widget (loaded from `checkout.razorpay.com`, no npm dependency needed
  in the browser bundle). Webhook at `POST /api/webhooks/razorpay` verifies the HMAC-SHA256
  signature before processing, handles `subscription.activated/charged`,
  `subscription.cancelled/completed`, and `payment.failed`. Cancellation is a direct API
  call (Razorpay has no hosted portal equivalent) — `cancelRazorpaySubscriptionAction`.
- **Idempotency** (required by your spec): both webhook handlers insert into
  `payment_events` first, keyed by a unique `provider_event_id`
  (Stripe's real event ID; a synthetic `type:entityId:timestamp` key for Razorpay, which
  doesn't expose one directly). A duplicate delivery hits the unique constraint, the
  handler acknowledges and returns immediately — **the subscription-mutating code below
  it never runs twice for the same event.**
- **Schema addition**: `supabase/migrations/0005_subscriptions_unique.sql` adds a unique
  constraint on `provider_subscription_id`, needed so the webhook upserts are safe to
  run repeatedly. Run this migration too.
- Card details are never touched by this app — both flows redirect to the provider's own
  hosted, PCI-compliant checkout page/widget.

### Setting this up
1. Pick Stripe or Razorpay (or configure different plans on each). Create the actual
   Price (Stripe) or Plan (Razorpay) in that provider's dashboard first.
2. Insert a row into `membership_plans` with `provider` set to `'stripe'` or
   `'razorpay'` and `provider_price_id` set to that Price/Plan ID — the pricing page and
   checkout route read this, nothing is hardcoded.
3. Fill in the matching `.env` section (`STRIPE_SECRET_KEY` + `STRIPE_WEBHOOK_SECRET`, or
   `RAZORPAY_KEY_ID` + `RAZORPAY_KEY_SECRET` + `RAZORPAY_WEBHOOK_SECRET`).
4. Point the provider's webhook at `https://yourdomain.com/api/webhooks/stripe` or
   `/api/webhooks/razorpay` and copy the signing secret it gives you into `.env`.
5. **I could not test any of this against a live Stripe/Razorpay account** — no network
   access in this sandbox. Test with each provider's test/sandbox mode before going live,
   especially the webhook signature verification and the idempotency behavior (trigger
   the same test event twice and confirm the subscription only updates once).

## Phase 11 & 12 additions (this pass): Admin panel completion + tests + reorder

- **Users** (`/admin/users`): list every account with role controls (free/paid/admin).
  Role changes go through a **service-role server action**
  (`src/app/actions/admin-users.ts`) — not because RLS allows it, but because the
  `role` column has its UPDATE grant revoked for the `authenticated` Postgres role
  entirely (Phase 1), which blocks even a genuine admin's request through the normal
  client. `requireAdmin()` gates who can reach the action; the service-role client is
  what makes the actual write possible once they're through that gate.
- **Membership plans** (`/admin/plans`): full CRUD, activate/deactivate — this is the
  table the pricing page and checkout route both read from, so a plan created here with
  a `provider_price_id` set is immediately live for real checkout.
- **Announcements** and **Live sessions** (`/admin/announcements`, `/admin/live-sessions`):
  create/delete, feeding the public `/community` page built in Phase 9.
- **Courses & lessons** (`/admin/courses`): create/edit/publish/delete courses, add
  modules and lessons inline, and a dedicated lesson editor (title, video embed URL,
  body content, paid/free toggle, publish status) — this is what the `/learn` pages
  built in Phase 5 actually read from.
- **Playbook reordering** (`/admin/playbooks`): up/down controls, grouped by model so
  reordering QT setups can never touch GXT's order — swaps `sort_order` between two
  adjacent rows via `swapPlaybookOrderAction`.
- **Tests** (`src/lib/finance/__tests__/`): unit tests for every formula in
  `calculators.ts` and `analytics.ts`, including the edge cases that matter most —
  zero stop distance, zero account balance, empty trade lists, all-winning and
  all-losing trade sets. `vitest.config.ts` is set up and `npm test` will run them —
  **but I could not install vitest or execute them here** (no network access in this
  sandbox). I instead re-implemented each formula in plain Node and manually confirmed
  every expected value in the test file matches the real output — the tests are correct
  as written, but run `npm test` yourself as the actual verification once you have
  network access.

## What's NOT built (known, final gaps)

- No automated tests beyond the finance formulas (auth flows, ownership isolation,
  webhook idempotency, and form validation are all described in this README as things
  to verify manually / add tests for, but aren't covered by an automated suite yet)
- No CI pipeline
- Lesson `body` content renders as plain text, not real Markdown — swap in a Markdown
  renderer (e.g. `react-markdown`) in `src/app/learn/[courseId]/[lessonId]/page.tsx`
  and `src/components/admin/lesson-form.tsx` if you want formatted lesson content
- Nothing here has been run against a live Next.js dev server, `npm run build`, or a
  real Supabase/Stripe/Razorpay account — see the environment note at the top of this
  file. That is the single most important thing to do before trusting this in production.

## Overall status

Every feature area from your original spec now has both a database layer (schema + RLS)
and a working UI, including payments. What's left is verification (tests, a real build,
real provider sandboxes) rather than unbuilt features. Treat this as a complete first
version to test thoroughly, not as something to deploy straight to production.

## IMPORTANT environment note

This code was written in a sandbox with no internet access, so I could not run
`npm install`, start a dev server, or execute a real test suite here. The SQL schema was
validated by hand (types, keys, RLS logic); the calculator/analytics formulas were
verified with plain Node against known inputs (see console output when this was built).
Before you trust this in production: run it locally, run `npm run build`, and run real
tests once phase 12 is built.

## Local setup

1. Install dependencies:
   ```
   npm install
   ```
2. Create a Supabase project at https://supabase.com → Project Settings → API to get
   your URL and anon key. Copy `.env.example` to `.env.local` and fill in:
   - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (Project Settings → API → service_role — keep secret)
3. Run the migrations against your Supabase project, in order:
   ```
   supabase db push
   ```
   or paste `0001_init.sql`, `0002_rls.sql`, `0003_storage.sql` into the Supabase SQL editor,
   in that order.
4. Make your own user an admin: after signing up once, run in the SQL editor:
   ```sql
   update public.profiles set role = 'admin' where id = '<your-auth-user-id>';
   ```
5. Start the dev server:
   ```
   npm run dev
   ```

## Payments setup (when you reach that phase)

- **India-based business**: Razorpay is generally the more straightforward fit — verify
  current requirements at https://razorpay.com before committing, requirements change.
- **International**: Stripe, where available — check current country support at
  https://stripe.com/global before committing.
- Whichever you pick, fill in only that provider's `.env` section. Webhook handlers will
  verify signatures and write to `payment_events`/`subscriptions` using the service-role
  client (bypasses RLS by design — this is the one place that's appropriate).

## Adding your real QT/GXT/TTFM content

- Model overview/prerequisites text → `models` table (`overview`, `prerequisites` columns)
- Setups → `playbooks` table. Leave `is_verified_rule = false` until you've confirmed the
  rules are final; the admin UI (once built) will let you flip this and publish.
- Lessons/videos/PDFs → `lessons` table + Supabase Storage (`lesson-media` bucket)

## Deployment

- Recommended: Vercel (Next.js) + Supabase (already assumed). Push this repo to GitHub,
  import into Vercel, add the same environment variables from `.env.local` in the Vercel
  project settings, and deploy.

## Rebranding

Change the app name in `src/app/layout.tsx` (metadata) and `src/components/layout/navbar.tsx`.
Change colors in `tailwind.config.ts` under `theme.extend.colors`.
